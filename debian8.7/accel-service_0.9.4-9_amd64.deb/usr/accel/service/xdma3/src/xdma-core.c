#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/delay.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/jiffies.h>

#include "xdma-core.h"

/* the "first_descriptor" registers are in the SGDMA RTL target */
#define USE_RTL_SGDMA_TARGET 1

/* optimistic back-to-back I/O chaining */
/* this is not compatible with descriptors above 32-bit address range,
 * as the implementation depends on atomically writing 32-bits in host
 * memory to link descriptors */
#define CHAIN_MULTIPLE_TRANSFERS 0

/* for test purposes only, not in default IP! */
#define DESC_COUNTER 0

MODULE_LICENSE ("GPL v2");

#define DRV_NAME "xdma_driver3"
#define XDMA_KNOWN_REVISION (0x01)
static const char *names = "xdma_driver3";

#define MAX_EXTRA_ADJ (15)
#define RX_STATUS_EOP (1)

#ifndef __devinit
#  define __devinit
#endif

#ifndef __devexit
#  define __devexit
#endif

/* Target internal components on BAR1 */
#define XDMA_OFS_CONFIG         (0x0000UL)
#define XDMA_OFS_INT_CTRL       (0x2000UL)
#define XDMA_OFS_SCRATCH_PAD    (0x3020UL)

/* obtain the 32 most significant (high) bits of a 32-bit or 64-bit address */
#define pci_dma_h(addr) ((addr >> 16) >> 16)
/* obtain the 32 least significant (low) bits of a 32-bit or 64-bit address */
#define pci_dma_l(addr) (addr & 0xffffffffUL)

/* sys filesystem */
struct class *g_xdma_class;

static unsigned int major = 0;
module_param (major, uint, 0644);
MODULE_PARM_DESC (major, "Character device major number, 0 for dynamic selection which is default.");

static unsigned int msi = 1;
module_param (msi, uint, 0644);
MODULE_PARM_DESC (msi, "Use 0 to disable MSI interrupting, default is 1 to use MSI interrupting.");

static int bar_map_sizes_min[6] = { 0, XDMA_BAR_SIZE, 0, 0, 0 , 0 };
module_param_array (bar_map_sizes_min, int, NULL/* not interested in count */, 0644);
MODULE_PARM_DESC (bar_map_sizes_min, "Array of BAR minimally required BAR mapping sizes in bytes.");

static int bar_map_sizes_max[6] = { INT_MAX, INT_MAX, INT_MAX, INT_MAX, INT_MAX, INT_MAX, };
static int bar_map_sizes_max_nr;
module_param_array (bar_map_sizes_max, int, &bar_map_sizes_max_nr, 0644);
MODULE_PARM_DESC (bar_map_sizes_max, "Array of BAR maximal mapping sizes in bytes. 0 means do not map, -1 means map complete BAR.");

static int bar_map_sizes[6];

static const struct pci_device_id pci_ids[] = {
    { PCI_DEVICE (0x10ee, 0x8013), },
//    { PCI_DEVICE (0x10ee, 0x8012), },
//    { PCI_DEVICE (0x10ee, 0x8014), },
//    { PCI_DEVICE (0x10ee, 0x8018), },
    { PCI_DEVICE (0x10ee, 0x8021), },
    { PCI_DEVICE (0x10ee, 0x8022), },
    { PCI_DEVICE (0x10ee, 0x8024), },
    { PCI_DEVICE (0x10ee, 0x8028), },
    { PCI_DEVICE (0x10ee, 0x8031), },
    { PCI_DEVICE (0x10ee, 0x8032), },
    { PCI_DEVICE (0x10ee, 0x8034), },
    { PCI_DEVICE (0x10ee, 0x8038), },
    { PCI_DEVICE (0x10ee, 0x7011), },
    { PCI_DEVICE (0x10ee, 0x7012), },
    { PCI_DEVICE (0x10ee, 0x7014), },
    { PCI_DEVICE (0x10ee, 0x7018), },
    { PCI_DEVICE (0x10ee, 0x7021), },
    { PCI_DEVICE (0x10ee, 0x7022), },
    { PCI_DEVICE (0x10ee, 0x7024), },
    { PCI_DEVICE (0x10ee, 0x7028), },
    { PCI_DEVICE (0x10ee, 0x7031), },
    { PCI_DEVICE (0x10ee, 0x7032), },
    { PCI_DEVICE (0x10ee, 0x7034), },
    { PCI_DEVICE (0x10ee, 0x7038), },
    { 0, }
};
MODULE_DEVICE_TABLE (pci, pci_ids);

static int instance = 0;

static char dev_present[MAX_XDMA_DEVICES];

// device attribute
// returns major and instance device numbers
ssize_t show_device_numbers (struct device *dev, struct device_attribute *attr, char *buf) {
    struct xdma_dev *lro;
    lro = (struct xdma_dev *)dev_get_drvdata (dev);
    return snprintf (buf, PAGE_SIZE, "%d\t%d\n", lro->major, lro->instance);
}
static DEVICE_ATTR (xdma_dev_instance, S_IRUGO, show_device_numbers, NULL);

// prototypes
static struct xdma_transfer *transfer_create_kernel (struct xdma_dev *lro, const char *start, size_t count, u64 ep_addr, int dir_to_dev, int force_new_desc);

static int transfer_queue (struct xdma_engine *engine, struct xdma_transfer *transfer);
static void transfer_dump (struct xdma_transfer *transfer);
static void transfer_destroy (struct xdma_dev *lro, struct xdma_transfer *transfer);

static struct xdma_desc *xdma_desc_alloc (struct pci_dev *dev, int number, dma_addr_t *desc_bus_p, struct xdma_desc **desc_last_p);
static void xdma_desc_link (struct xdma_desc *first, struct xdma_desc *second, dma_addr_t second_bus);
static void xdma_desc_set (struct xdma_desc *desc, dma_addr_t rc_bus_addr, u64 ep_addr, int len, int dir_to_dev);
static void xdma_desc_control (struct xdma_desc *first, u32 control_field);
static void xdma_desc_set_source (struct xdma_desc *desc, u64 source);

static void xdma_transfer_cyclic (struct xdma_transfer *transfer);

static struct xdma_char *create_sg_char (struct xdma_dev *lro);
static int destroy_sg_char (struct xdma_char *lro_char);

static u32 engine_status_read (struct xdma_engine *engine, int clear);

static void log_error_in_csr (void *target, u32 line, int type);





//===========
// utilities
//===========

static void *rvmalloc (unsigned long size) {
    void *mem;
    unsigned long adr;

    size = PAGE_ALIGN (size);
    mem = vmalloc_32 (size);
    if (!mem) {
        return NULL;
    }

    adr = (unsigned long)mem;
    while (size > 0) {
        SetPageReserved (vmalloc_to_page ((void *)adr));
        adr += PAGE_SIZE;
        size -= PAGE_SIZE;
    }
    //printk(KERN_INFO "Alloc mem in rvmalloc %x\n", mem);
    return mem;
}

/* free reserved vmalloc()ed memory */
static void rvfree (void *mem, unsigned long size) {
    unsigned long adr;
    if (!mem) {
        return;
    }
    adr = (unsigned long)mem;
    while ((long) size > 0) {
        ClearPageReserved (vmalloc_to_page ((void *)adr));
        adr += PAGE_SIZE;
        size -= PAGE_SIZE;
    }
    //printk(KERN_INFO "Free mem in rvfree %x\n", mem);
    vfree (mem);
}

/*
 * Unmap the BAR regions that had been mapped earlier using map_bars()
 */
static void unmap_bars (struct xdma_dev *lro, struct pci_dev *dev) {
    int i;
    for (i = 0; i < XDMA_BAR_NUM; i++) {
        /* is this BAR mapped? */
        if (lro->bar[i]) {
            /* unmap BAR */
            pci_iounmap (dev, lro->bar[i]);
            /* mark as unmapped */
            lro->bar[i] = NULL;
        }
    }
}

/* map_bars() -- map device regions into kernel virtual address space
 *
 * Map the device memory regions into kernel virtual address space after
 * verifying their sizes respect the minimum sizes needed, given by the
 * bar_map_sizes[] array.
 */
static int __devinit map_bars (struct xdma_dev *lro, struct pci_dev *dev) {
    int rc;
    int i;

    /* iterate through all the BARs */
    for (i = 0; i < XDMA_BAR_NUM; i++) {
        resource_size_t bar_start = pci_resource_start (dev, i);
        resource_size_t bar_end = pci_resource_end (dev, i);
        resource_size_t bar_length = pci_resource_len (dev, i);
        resource_size_t map_length = bar_length;
        lro->bar[i] = NULL;

        /* skip non-present BAR2 and higher */
        if ((!bar_length) && (i >= 2)) {
            continue;
        }

        /* do not map BARs with length 0. Note that start MAY be 0! */
        if (!bar_length) {
            printk (KERN_DEBUG "BAR #%d is not present???\n", i);
            printk (KERN_DEBUG "pci_resource_start(... , %d) = 0x%llx.\n", i, (unsigned long long)bar_start);
            printk (KERN_DEBUG "pci_resource_end(... , %d) = 0x%llx.\n", i, (unsigned long long)bar_end);
            rc = -1;
            goto fail;
        }

        /* BAR length is less than driver requires? */
        if (bar_length < bar_map_sizes_min[i]) {
            printk (KERN_INFO "Failing, driver parameter bar_map_sizes_min[%d] requires %llu bytes, but BAR #%d is only %llu\n",
                    i, (unsigned long long)bar_map_sizes_min[i], i, (unsigned long long)bar_length);
            rc = -1;
            goto fail;
        }

        printk (KERN_INFO "bar_map_sizes_max[%d]=%d\n", i, bar_map_sizes_max[i]);

        /* do not map, and skip, specified BAR mapping with length 0 */
        if (bar_map_sizes_max[i] == 0) {
            printk (KERN_INFO "Skipping BAR #i mapping due to driver parameter bar_map_sizes_max[%d]=0\n", i);
            continue;
            /* BAR size exceeds maximum desired mapping? */
        }
        else if (bar_length > bar_map_sizes_max[i]) {
            printk (KERN_INFO "Limiting BAR #%d mapping from %llu to %llu bytes, given by driver parameter bar_map_sizes_max[%d] %llu bytes\n",
                    i, (unsigned long long)bar_start, (unsigned long long)bar_length, i, (unsigned long long)bar_map_sizes_max[i]);
            map_length = (resource_size_t)bar_map_sizes_max[i];
        }

        /* map the full device memory or IO region into kernel virtual
         * address space */
        dbg_init ("BAR%d: %llu bytes to be mapped.\n", i, (unsigned long long)map_length);
        lro->bar[i] = pci_iomap (dev, i, map_length);

        if (!lro->bar[i]) {
            printk (KERN_DEBUG "Could not map BAR #%d. See bar_map_size option to reduce the map size.\n", i);
            rc = -1;
            goto fail;
        }

        bar_map_sizes[i] = bar_length;

        dbg_init ("BAR[%d] at 0x%llx mapped at 0x%p with length "
                  "%llu(/%llu).\n", i, (unsigned long long)bar_start,
                  lro->bar[i],
                  (unsigned long long)map_length,
                  (unsigned long long)bar_length);
    }

    /* succesfully mapped all required BAR regions */
    rc = 0;
    goto success;
fail:
    /* unwind; unmap any BARs that we did map */
    unmap_bars (lro, dev);
success:
    return rc;
}

/* xdma_config -- Inspect the XDMA IP Core configuration */
static int xdma_config (struct xdma_dev *lro, unsigned int config_offset) {
    struct config_regs *reg = (struct config_regs *) (lro->bar[XDMA_BAR_XDMA] + config_offset);
    u32 w;
    int rc = 0;
    w = read_register (&reg->identifier);
    printk (KERN_INFO "xdma_config(): ID = 0x%08x\n", w);
    return rc;
}





//===========
// interrupt
//===========

static int interrupt_status (struct xdma_dev *lro) {
    struct interrupt_regs *reg = (struct interrupt_regs *) (lro->bar[XDMA_BAR_XDMA] + XDMA_OFS_INT_CTRL);
    u32 w;
    int rc = 0;

    dbg_irq ("reg = %p\n", reg);
    dbg_irq ("&reg->user_int_enable = %p\n", &reg->user_int_enable);

    w = read_register (&reg->user_int_enable);
    dbg_irq ("user_int_enable = 0x%08x\n", w);

    w = read_register (&reg->channel_int_enable);
    dbg_irq ("channel_int_enable = 0x%08x\n", w);

    w = read_register (&reg->user_int_request);
    dbg_irq ("user_int_request = 0x%08x\n", w);

    w = read_register (&reg->channel_int_request);
    dbg_irq ("channel_int_request = 0x%08x\n", w);

    w = read_register (&reg->user_int_pending);
    dbg_irq ("user_int_pending = 0x%08x\n", w);

    w = read_register (&reg->channel_int_pending);
    dbg_irq ("channel_int_pending = 0x%08x\n", w);

    return rc;
}

/* interrupts_enable -- Enable the interrupts we are interested in */
static int interrupts_enable (struct xdma_dev *lro, int interrupts_offset, u32 mask) {
    //void *reg = lro->bar[XDMA_BAR_XDMA] + interrupts_offset;
    struct interrupt_regs *reg = (struct interrupt_regs *) (lro->bar[XDMA_BAR_XDMA] + XDMA_OFS_INT_CTRL);

    u32 w, v;
    int rc = 0;

    /* implementation with W1S register */
    write_register (mask, &reg->channel_int_enable_w1s);

    /* read back (flushes write) */
    v = read_register (&reg->channel_int_enable);

    if ((v & mask) == 0) {
        printk (KERN_DEBUG "interrupts_enable(): wrote W1S mask: 0x%08x, read back: 0x%08x \n", mask, v);
    }

    return rc;
}

/* interrupts_disable -- Disable the interrupts we are no longer interested in */
static int interrupts_disable (struct xdma_dev *lro, int interrupts_offset, u32 mask) {
    //void *reg = lro->bar[XDMA_BAR_XDMA] + interrupts_offset;
    struct interrupt_regs *reg = (struct interrupt_regs *) (lro->bar[XDMA_BAR_XDMA] + XDMA_OFS_INT_CTRL);
    u32 w, v;
    int rc = 0;
    //printk(KERN_DEBUG "Read register at BAR %d, address 0x%08x.\n", XDMA_BAR_XDMA, reg);

    /* implementation with W1C register */
    write_register (mask, &reg->channel_int_enable_w1c);

    /* flush previous writes using a dummy read */
    v = read_register (&reg->channel_int_enable);

    if (v & mask) {
        printk (KERN_DEBUG "interrupts_disable(): wrote W1C mask: 0x%08x, read back: 0x%08x \n", mask, v);
    }

    return rc;
}

/* read_interrupts -- Print the interrupt controller status */
static u32 read_interrupts (struct xdma_dev *lro, int interrupts_offset) {
    struct interrupt_regs *reg = (struct interrupt_regs *) (lro->bar[XDMA_BAR_XDMA] + XDMA_OFS_INT_CTRL);
    u32 r;
    u32 w;

    /* extra debugging; inspect complete engine set of registers */
    w = read_register (&reg->user_int_request);
    /* return user interrupts in upper 16-bits */
    r = (w & 0xffffU) << 16;
    dbg_io ("ioread32(0x%p) returned 0x%08x (user_int_request).\n", &reg->user_int_request, w);
    w = read_register (&reg->channel_int_request);
    /* return user interrupts in lower 16-bits */
    r |= (w & 0xffffU);
    /* return user interrupts in upper 16-bits */
    dbg_io ("ioread32(0x%p) returned 0x%08x (channel_int_request)\n", &reg->channel_int_request, w);
    return r;
}

/*
 * xdma_isr() - Interrupt handler
 *
 * @dev_id pointer to xdma_dev
 */
static irqreturn_t xdma_isr (int irq, void *dev_id) {
    u32 ch_irq;
    u32 user_irq;
    struct xdma_dev *lro;
    struct interrupt_regs *irq_regs;
    int dir_from_dev;
    unsigned long flags;

    dbg_irq ("xdma_isr(irq=%d) <<<<<<<<<<<<<<<< INTERRUPT SERVICE ROUTINE\n", irq);
    BUG_ON (!dev_id);

    lro = (struct xdma_dev *) dev_id;

    if (!lro) {
        WARN_ON (!lro);
        printk (KERN_DEBUG "xdma_isr(irq=%d) lro=%p ??\n", irq, lro);
        return IRQ_NONE;
    }

    irq_regs = (struct interrupt_regs *) (lro->bar[XDMA_BAR_XDMA] + XDMA_OFS_INT_CTRL);

    /* read channel interrupt requests */
    ch_irq = read_register (&irq_regs->channel_int_request);
    dbg_irq ("read_interrupts() = 0x%08x\n", ch_irq);

    /* disable all interrupts that fired; these are re-enabled individually
     * after the causing module has been fully serviced.
     * note: this write has to be flushed, done with read below */
    write_register (ch_irq, &irq_regs->channel_int_enable_w1c);
    //interrupts_disable(lro, XDMA_OFS_INT_CTRL, ch_irq);

    /* read user interrupts */
    /* flushes previous write */
    user_irq = read_register (&irq_regs->user_int_request);

    /* iterate over H2C (PCIe read), then C2H (PCIe write) */
    for (dir_from_dev = 0; dir_from_dev < 2; dir_from_dev++) {
        int dir_to_dev = !dir_from_dev;
        int channel;
        /* iterate over channels */
        for (channel = 0; channel < XDMA_CHANNEL_NUM_MAX; channel++) {
            struct xdma_engine *engine = lro->engine[channel][dir_from_dev];
            /* engine present and its interrupt fired? */
            if (engine && (engine->irq_bitmask & ch_irq)) {
                dbg_tfr ("schedule_work(engine = %p)\n", engine);
                schedule_work (&engine->work);
            }
        }
    }

    dbg_irq ("user_irq = 0x%08x\n", user_irq);

    spin_lock_irqsave (&lro->events_lock, flags);
    /* new irq events ? */
    if ((lro->events_irq | user_irq) != lro->events_irq) {
        dbg_irq ("wake_up_interruptible(events_wq) because 0x%08lx | 0x%08lx = 0x%08lx != 0x%08lx\n",
                 lro->events_irq, user_irq, lro->events_irq | user_irq, lro->events_irq);
        /* accumulate events into the pending mask */
        lro->events_irq |= user_irq;
        wake_up_interruptible (&lro->events_wq);
    }
    spin_unlock_irqrestore (&lro->events_lock, flags);

    lro->irq_count++;
    return IRQ_HANDLED;
}





//========
// engine
//========

/**
 * engine_status_read() - read status of SG DMA engine (optionally reset)
 *
 * Stores status in engine->status.
 *
 * @return -1 on failure, status register otherwise
 */
static u32 engine_status_read (struct xdma_engine *engine, int clear) {
    u32 value, w, desc_completed;
    BUG_ON (!engine);

#if XDMA_STATUS_DUMPS
    dbg_tfr ("ioread32(0x%p).\n", &engine->regs->identifier);
    w = read_register (&engine->regs->identifier);
    dbg_tfr ("ioread32(0x%p) returned 0x%08x.\n", &engine->regs->identifier, w);
    w &= 0xfff00000UL;

    if (w != 0x1fc00000UL) {
        printk (KERN_ERR "engine identifier not found (found 0x%08x expected 0xad4bXX01).\n", w);
        value = 0xffffffff;
        goto fail_identifier;
    }

    /* extra debugging; inspect complete engine set of registers */
    w = read_register (&engine->regs->status);
    dbg_tfr ("ioread32(0x%p) returned 0x%08x (status).\n", &engine->regs->status, w);
    w = read_register (&engine->regs->control);
    dbg_tfr ("ioread32(0x%p) returned 0x%08x (control)\n", &engine->regs->control, w);
    w = read_register (&engine->sgdma_regs->first_desc_lo);
    dbg_tfr ("ioread32(0x%p) returned 0x%08x (first_desc_lo)\n", &engine->sgdma_regs->first_desc_lo, w);
    w = read_register (&engine->sgdma_regs->first_desc_hi);
    dbg_tfr ("ioread32(0x%p) returned 0x%08x (first_desc_hi)\n", &engine->sgdma_regs->first_desc_hi, w);
    w = read_register (&engine->sgdma_regs->first_desc_adjacent);
    dbg_tfr ("ioread32(0x%p) returned 0x%08x (first_desc_adjacent).\n", &engine->sgdma_regs->first_desc_adjacent, w);
    w = read_register (&engine->regs->completed_desc_count);
    dbg_tfr ("ioread32(0x%p) returned 0x%08x (completed_desc_count).\n", &engine->regs->completed_desc_count, w);
    w = read_register (&engine->regs->interrupt_enable_mask);
    dbg_tfr ("ioread32(0x%p) returned 0x%08x (interrupt_enable_mask)\n", &engine->regs->interrupt_enable_mask, w);
#endif

    /* read status register */
    dbg_tfr ("Status of SG DMA %s engine:\n", engine->name);
    dbg_tfr ("ioread32(0x%p).\n", &engine->regs->status);

    if (clear) {
        value = engine->status = read_register (&engine->regs->status_rc);
    }
    else {
        value = engine->status = read_register (&engine->regs->status);
    }

    dbg_tfr ("status = 0x%08x: %s%s%s%s%s%s%s%s%s\n", (u32)engine->status,
             (value & XDMA_STAT_BUSY) ? "BUSY " : "IDLE ",
             (value & XDMA_STAT_DESCRIPTOR_STOPPED) ? "DESCRIPTOR_STOPPED " : "",
             (value & XDMA_STAT_DESCRIPTOR_COMPLETED) ? "DESCRIPTOR_COMPLETED " : "",
             (value & XDMA_STAT_ALIGN_MISMATCH) ? "ALIGN_MISMATCH " : "",
             (value & XDMA_STAT_MAGIC_STOPPED) ? "MAGIC_STOPPED " : "",
             (value & XDMA_STAT_FETCH_STOPPED) ? "FETCH_STOPPED " : "",
             (value & XDMA_STAT_READ_ERROR) ? "READ_ERROR " : "",
             (value & XDMA_STAT_DESCRIPTOR_ERROR) ? "DESCRIPTOR_ERROR " : "",
             (value & XDMA_STAT_IDLE_STOPPED) ? "IDLE_STOPPED " : "");

    if (value & XDMA_STAT_BUSY) {
        /* read number of completed descriptors after engine start */
        desc_completed = read_register (&engine->regs->completed_desc_count);
        dbg_tfr ("desc_completed = %d\n", desc_completed);
    }

fail_identifier:
    return value;
}

/**
 * xdma_engine_stop() - stop an SG DMA engine
 */
static void xdma_engine_stop (struct xdma_engine *engine) {
    u32 w;
    dbg_tfr ("xdma_engine_stop(engine=%p)\n", engine);
    BUG_ON (!engine);

    w = (u32)XDMA_CTRL_IE_DESCRIPTOR_STOPPED;
    w |= (u32)XDMA_CTRL_IE_DESCRIPTOR_COMPLETED;
    w |= (u32)XDMA_CTRL_IE_DESCRIPTOR_ALIGN_MISMATCH;
    w |= (u32)XDMA_CTRL_IE_MAGIC_STOPPED;

    // Disable IDLE STOPPED for MM
    if (engine->streaming && (engine->dir_to_dev == 0)) {
        w |= (u32)XDMA_CTRL_IE_IDLE_STOPPED;
    }

    w |= (u32)XDMA_CTRL_IE_READ_ERROR;
    w |= (u32)XDMA_CTRL_IE_DESCRIPTOR_ERROR;

    dbg_tfr ("Stopping SG DMA %s engine; writing 0x%08x to 0x%p.\n",
             engine->name, w, (u32 *)&engine->regs->control);
    write_register (w, &engine->regs->control);
    /* dummy read of status register to flush all previous writes */
    read_register (&engine->regs->status);
    dbg_tfr ("xdma_engine_stop(%s) done\n", engine->name);
}

/**
 * engine_cyclic_stop() - stop a cyclic transfer running on an SG DMA engine
 *
 * engine->lock must be taken
 */
struct xdma_transfer *engine_cyclic_stop (struct xdma_engine *engine) {
    struct xdma_transfer *transfer = 0;

    /* transfers on queue? */
    if (!list_empty (&engine->transfer_list)) {
        /* pick first transfer on the queue (was submitted to the engine) */
        transfer = list_entry (engine->transfer_list.next, struct xdma_transfer, entry);
        BUG_ON (!transfer);

        xdma_engine_stop (engine);

        if (transfer->cyclic) {
            if (engine->xdma_perf) {
                dbg_perf ("Stopping cyclic performance transfer on %s engine\n", engine->name);
            }
            else {
                printk (KERN_DEBUG "Stopping cyclic transfer on %s engine\n", engine->name);
            }
            /* make sure the service handler sees the correct transfer state */
            transfer->cyclic = 1;
            /* set STOP flag and interrupt on completion, on the last descriptor */
            xdma_desc_control (transfer->desc_virt + transfer->desc_num - 1, XDMA_DESC_COMPLETED | XDMA_DESC_STOP);
        }
        else {
            printk (KERN_DEBUG "engine_cyclic_stop(engine=%p) running transfer is not cyclic, calling xdma_engine_stop()\n", engine);
        }
    }
    else {
        printk (KERN_DEBUG "engine_cyclic_stop(engine=%p) found no running transfer.\n", engine);
    }
    return transfer;
}

/**
 * engine_start() - start an idle engine with its first transfer on queue
 *
 * The engine will run and process all transfers that are queued using
 * transfer_queue() and thus have their descriptor lists chained.
 *
 * During the run, new transfers will be processed if transfer_queue() has
 * chained the descriptors before the hardware fetches the last descriptor.
 * A transfer that was chained too late will invoke a new run of the engine
 * initiated from the engine_service() routine.
 *
 * The engine must be idle and at least one transfer must be queued.
 * This function does not take locks; the engine spinlock must already be taken.
 *
 */
static struct xdma_transfer *engine_start (struct xdma_engine *engine) {
    struct xdma_transfer *transfer;
    u32 w;
    int extra_adj = 0;
    /* engine must be idle */
    BUG_ON (engine->running);
    /* engine transfer queue must not be empty */
    BUG_ON (list_empty (&engine->transfer_list));
    /* inspect first transfer queued on the engine */
    transfer = list_entry (engine->transfer_list.next, struct xdma_transfer, entry);
    BUG_ON (!transfer);

    /* engine is no longer shutdown */
    engine->shutdown = 0;

    dbg_tfr ("engine_start(%s): transfer=0x%p.\n", engine->name, transfer);

    /* initialize number of descriptors of dequeued transfers */
    engine->desc_dequeued = 0;

    /* write lower 32-bit of bus address of transfer first descriptor */
    w = cpu_to_le32 (pci_dma_l (transfer->desc_bus));
    dbg_tfr ("iowrite32(0x%08x to 0x%p) (first_desc_lo)\n", w,
             (void *)&engine->sgdma_regs->first_desc_lo);

    write_register (w, &engine->sgdma_regs->first_desc_lo);

    /* write upper 32-bit of bus address of transfer first descriptor */
    w = cpu_to_le32 (pci_dma_h (transfer->desc_bus));

    dbg_tfr ("iowrite32(0x%08x to 0x%p) (first_desc_hi)\n", w,
             (void *)&engine->sgdma_regs->first_desc_hi);

    write_register (w, &engine->sgdma_regs->first_desc_hi);

    if (transfer->desc_adjacent > 0) {
        extra_adj = transfer->desc_adjacent - 1;
        if (extra_adj > MAX_EXTRA_ADJ) {
            extra_adj = MAX_EXTRA_ADJ;
        }
    }

    dbg_tfr ("iowrite32(0x%08x to 0x%p) (first_desc_adjacent)\n",
             extra_adj, (void *)&engine->sgdma_regs->first_desc_adjacent);

    write_register (extra_adj, &engine->sgdma_regs->first_desc_adjacent);

    dbg_tfr ("ioread32(0x%p) (dummy read flushes writes).\n", &engine->regs->status);

    /* dummy read of status register to flush all previous writes */
    //read_register(&engine->regs->status);
    mmiowb ();

    /* write control register of SG DMA engine */
    w = (u32)XDMA_CTRL_RUN_STOP;
    w |= (u32)XDMA_CTRL_IE_DESCRIPTOR_STOPPED;
    w |= (u32)XDMA_CTRL_IE_DESCRIPTOR_COMPLETED;
    w |= (u32)XDMA_CTRL_IE_DESCRIPTOR_ALIGN_MISMATCH;
    w |= (u32)XDMA_CTRL_IE_MAGIC_STOPPED;

    /* enable IE_IDLE_STOP only for AXI ST C2H */
    if (engine->streaming && !engine->dir_to_dev) {
        w |= (u32)XDMA_CTRL_IE_IDLE_STOPPED;
    }

    /* set non-incremental addressing mode */
    if (engine->non_incr_addr) {
        w |= (u32)XDMA_CTRL_NON_INCR_ADDR;
    }

    w |= (u32)XDMA_CTRL_IE_READ_ERROR;
    w |= (u32)XDMA_CTRL_IE_DESCRIPTOR_ERROR;

    dbg_tfr ("iowrite32(0x%08x to 0x%p) (control)\n", w, (void *)&engine->regs->control);
    /* start the engine */
    write_register (w, &engine->regs->control);

#if XDMA_STATUS_DUMPS
    /* read status register and report */
    engine_status_read (engine, 0);
#else
    /* dummy read of status register to flush all previous writes */
    w = read_register (&engine->regs->status);
    dbg_tfr ("ioread32(0x%p) = 0x%lx (dummy read flushes writes).\n",
             &engine->regs->status, (unsigned long)w);
#endif

    dbg_tfr ("%s engine 0x%p now running\n", engine->name, engine);
    /* remember the engine is running */
    engine->running = 1;
    return transfer;
}

/* must be called with engine->lock already acquired */
static int engine_service_cyclic (struct xdma_engine *engine) {
    struct xdma_result *result;
    int eop_count = 0;
    int start;

    printk (KERN_INFO "engine_service_cyclic()");

    BUG_ON (!engine);
    BUG_ON (engine->magic != MAGIC_ENGINE);

    result = (struct xdma_result *)engine->rx_result_buffer_virt;
    BUG_ON (!result);

    /* read status register */
    engine_status_read (engine, 1);

    /* where we start receiving in the ring buffer */
    start = engine->rx_tail;

    dbg_tfr ("result[engine->rx_tail=%3d].status = 0x%08x, rx->length = %d\n",
             engine->rx_tail, (int)result[engine->rx_tail].status, (int)result[engine->rx_tail].length);

    /* iterate through all newly received RX result descriptors */
    while (result[engine->rx_tail].status) {
        /* EOP bit set in result? */
        if (result[engine->rx_tail].status & RX_STATUS_EOP) {
            eop_count++;
        }

        dbg_tfr ("result[engine->rx_tail=%3d].status = 0x%08x, rx->length = %d\n",
                 engine->rx_tail, (int)result[engine->rx_tail].status, (int)result[engine->rx_tail].length);

        /* increment tail pointer */
        engine->rx_tail = (engine->rx_tail + 1) % RX_BUF_PAGES;

        /* overrun? */
        if (engine->rx_tail == engine->rx_head) {
            dbg_tfr ("engine_service_cyclic(): overrun\n");
            /* flag to user space that overrun has occured */
            engine->rx_overrun = 1;
            /* proceed the head pointer, skip to the last known-good point where new
             * packets may arrive, from previous iteration */
            while (engine->rx_head != start) {
                /* clear result */
                result[engine->rx_head].status = 0;
                result[engine->rx_head].length = 0;
                /* proceed head pointer so we make progress, even when faulty */
                engine->rx_head = (engine->rx_head + 1) % RX_BUF_PAGES;
            }
        }
    }

    /* wake any reader on EOP, as one or more packets are now in the RX buffer */
    if (eop_count > 0) {
        dbg_tfr ("engine_service_cyclic(): wake_up_interruptible() due to %d EOP's\n", eop_count);
        /* awake task on transfer's wait queue */
        wake_up_interruptible (&engine->rx_transfer_cyclic->wq);
    }

    /* engine was running but is no longer busy? */
    if (! (engine->status & XDMA_STAT_BUSY) && engine->running) {
        /* transfers on queue? */
        if (!list_empty (&engine->transfer_list)) {
            struct xdma_transfer *transfer;
            /* pick first transfer on the queue (was submitted to the engine) */
            transfer = list_entry (engine->transfer_list.next,
                                   struct xdma_transfer, entry);
            BUG_ON (!transfer);
            BUG_ON (transfer != engine->rx_transfer_cyclic);
            dbg_tfr ("%s engine completed cyclic transfer 0x%p (%d desc).\n",
                     engine->name, transfer, transfer->desc_num);
            /* remove completed transfer from list */
            list_del (engine->transfer_list.next);
        }
        /* if the engine stopped with RUN still asserted, de-assert RUN now */
        dbg_tfr ("engine_service_cyclic(): engine just went idle, resetting RUN_STOP.\n");
        xdma_engine_stop (engine);
        engine->running = 0;
        /* awake task on engine's shutdown wait queue */
        wake_up_interruptible (&engine->shutdown_wq);
    }
    return 0;
}

/**
 * engine_service() - service an SG DMA engine
 *
 * must be called with engine->lock already acquired
 *
 * @engine pointer to struct xdma_engine
 *
 */
static int engine_service (struct xdma_engine *engine) {
    u32 desc_completed;
    struct xdma_transfer *transfer = 0, *transfer_started;
    int lock_contended = spin_is_locked (&engine->lock);
    int cpu;

    //dbg_tfr("service() spinlock is %s\n", lock_contended? "locked": "unlocked");

    //dbg_tfr("service() got lock\n");
    /* determine current cpu */
    cpu = get_cpu ();
    put_cpu ();
    //dbg_tfr("service() got cpu\n");
    /* engine was not started by the driver? */
    if (!engine->running) {
        engine->prev_cpu = cpu;
        dbg_tfr ("service() engine was not running (?!) Clearing status.\n");
        engine_status_read (engine, 1);
        return 0;
    }

    dbg_tfr ("service() got lock\n");

    dbg_tfr ("service(): spinlock was %scontended, previous owner cpu #%d, this cpu #%d.\n",
             lock_contended ? "" : "not ", engine->prev_cpu, cpu);

    /* read-clear status register */
    engine_status_read (engine, 1);

    /* engine was running but is no longer busy? */
    if (engine->running && ! (engine->status & XDMA_STAT_BUSY)) {
        dbg_tfr ("service(): engine just went idle, resetting RUN_STOP.\n");
        xdma_engine_stop (engine);
        engine->running = 0;
        /* awake task on engine's shutdown wait queue */
        wake_up_interruptible (&engine->shutdown_wq);
    }

#define XDMA_STAT (XDMA_STAT_BUSY | \
    XDMA_STAT_DESCRIPTOR_COMPLETED | \
    XDMA_STAT_DESCRIPTOR_STOPPED | \
    XDMA_STAT_MAGIC_STOPPED)

    /* engine event which can forward our work? */
    if (engine->status & (XDMA_STAT_DESCRIPTOR_COMPLETED |
                          XDMA_STAT_DESCRIPTOR_STOPPED | XDMA_STAT_MAGIC_STOPPED |
                          XDMA_STAT_IDLE_STOPPED |
                          XDMA_STAT_READ_ERROR |
                          XDMA_STAT_DESCRIPTOR_ERROR |
                          XDMA_STAT_ALIGN_MISMATCH)) {
        if (engine->status & (XDMA_STAT_READ_ERROR | XDMA_STAT_DESCRIPTOR_ERROR | XDMA_STAT_ALIGN_MISMATCH)) {
            printk (KERN_DEBUG "engine_service(): ERROR was found in channel=%08x, status = %08x",
                    engine->channel, engine->status);
        }

        /* read number of completed descriptors after engine start */
        desc_completed = read_register (&engine->regs->completed_desc_count);
        dbg_tfr ("engine->regs->completed_desc_count = %d\n", desc_completed);

        /* transfers on queue? */
        if (!list_empty (&engine->transfer_list)) {
            /* pick first transfer on the queue (was submitted to the engine) */
            transfer = list_entry (engine->transfer_list.next,
                                   struct xdma_transfer, entry);

            dbg_tfr ("head of queue transfer 0x%p has %d descriptors, engine completed %d desc, %d not yet dequeued.\n",
                     transfer, (int)transfer->desc_num, (int)desc_completed, (int)desc_completed - engine->desc_dequeued);

            /* performance measurement is running? */
            if (engine->xdma_perf) {
                /* a descriptor was completed? */
                if (engine->status & XDMA_STAT_DESCRIPTOR_COMPLETED) {
                    engine->xdma_perf->iterations = desc_completed;
                    dbg_perf ("transfer->xdma_perf->iterations = %d\n", engine->xdma_perf->iterations);
                }
                /* a descriptor stopped the engine? */
                if (engine->status & XDMA_STAT_DESCRIPTOR_STOPPED) {
                    engine->xdma_perf->stopped = 1;
                    /* wake any XDMA_PERF_IOCTL_STOP waiting for the performance run to finish */
                    wake_up_interruptible (&engine->xdma_perf_wq);
                    dbg_perf ("transfer->xdma_perf stopped and woken up\n");
                }
            }
        }
        else {
            dbg_tfr ("no transfers on queue, but engine completed %d descriptors?!\n",
                     (int)desc_completed);
        }

        /* account for already dequeued transfers during this engine run */
        desc_completed -= engine->desc_dequeued;

        /* iterate over all the transfers completed by the engine,
         * except for the last (i.e. use > instead of >=). */
        while (transfer && (!transfer->cyclic) &&
               (desc_completed > transfer->desc_num)) {
            /* remove this transfer from desc_completed */
            desc_completed -= transfer->desc_num;
            dbg_tfr ("%s engine completed non-cyclic transfer 0x%p (%d desc).\n",
                     engine->name, transfer, transfer->desc_num);
            /* remove completed transfer from list */
            list_del (engine->transfer_list.next);
            /* add to dequeued number of descriptors during this run */
            engine->desc_dequeued += transfer->desc_num;
            /* mark transfer as succesfully completed */
            transfer->state = TRANSFER_STATE_COMPLETED;
            /* asynchronous I/O? */
            if ((transfer->iocb) && (transfer->last_in_request)) {
                struct kiocb *iocb = transfer->iocb;
                ssize_t done = transfer->size_of_request;
                dbg_tfr ("Freeing (async I/O request) last transfer %p, iocb %p\n", transfer, transfer->iocb);
                transfer_destroy (engine->lro, transfer);
                transfer = NULL;
                dbg_tfr ("Completing async I/O iocb %p with size %d\n", iocb, (int)done);
                /* indicate I/O completion XXX res, res2 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,1,0)
                aio_complete (iocb, done, 0);
#else
                iocb->ki_complete (iocb, done, 0);
#endif
                /* synchronous I/O? */
            }
            else {
                /* awake task on transfer's wait queue */
                wake_up_interruptible (&transfer->wq);
            }

            /* if exists, get the next transfer on the list */
            if (!list_empty (&engine->transfer_list)) {
                transfer = list_entry (engine->transfer_list.next,
                                       struct xdma_transfer, entry);
                printk (KERN_DEBUG "Non-completed transfer %p\n", transfer);
                /* no further transfers? */
            }
            else {
                transfer = NULL;
            }
        }

        /* inspect the current transfer */
        if (transfer) {
            /* engine stopped? (i.e. not busy and stop reason known? */
            if (((engine->status & XDMA_STAT_BUSY) == 0) &&
                (engine->status & (XDMA_STAT_MAGIC_STOPPED |
                                   XDMA_STAT_DESCRIPTOR_STOPPED |
                                   XDMA_STAT_IDLE_STOPPED |
                                   XDMA_STAT_ALIGN_MISMATCH |
                                   XDMA_STAT_READ_ERROR |
                                   XDMA_STAT_DESCRIPTOR_ERROR))) {
                dbg_tfr ("running %s engine has stopped\n", engine->name);
            }

            /* the engine still working on current transfer? */
            if (engine->status & XDMA_STAT_BUSY) {
                dbg_tfr ("running %s engine was %d descriptors into transfer 0x%p (with %d desc)\n",
                         engine->name, desc_completed, transfer, transfer->desc_num);
                /* engine has stopped  */
            }
            else {
                /* the engine failed on current transfer? */
                if (engine->status & (XDMA_STAT_MAGIC_STOPPED | XDMA_STAT_ALIGN_MISMATCH | XDMA_STAT_READ_ERROR | XDMA_STAT_DESCRIPTOR_ERROR))  {
                    dbg_tfr ("aborted %s engine was %d descriptors into transfer 0x%p (with %d desc) status= %d\n",
                             engine->name, desc_completed, transfer, transfer->desc_num, engine->status);
                    /* mark transfer as succesfully completed */
                    transfer->state = TRANSFER_STATE_FAILED;
                    xdma_engine_stop (engine);
                    /* the engine stopped on current transfer? */
                }
                else {
                    if (desc_completed < transfer->desc_num) {
                        transfer->state = TRANSFER_STATE_FAILED;
                        printk (KERN_DEBUG "Engine stopped half-way transfer %p\n", transfer);
                    }
                    else {
                        dbg_tfr ("stopped %s engine completed transfer 0x%p (%d desc), desc_completed = %d\n",
                                 engine->name, transfer, transfer->desc_num, desc_completed);
                        if (!transfer->cyclic) {
                            /* if the engine stopped on this transfer, it should be the last */
                            WARN_ON (desc_completed > transfer->desc_num);
                        }
                        /* mark transfer as succesfully completed */
                        transfer->state = TRANSFER_STATE_COMPLETED;
                    }
                }

                /* remove completed transfer from list */
                list_del (engine->transfer_list.next);
                /* add to dequeued number of descriptors during this run */
                engine->desc_dequeued += transfer->desc_num;

                /* asynchronous I/O? */
                if ((transfer->iocb) && (transfer->last_in_request)) {
                    struct kiocb *iocb = transfer->iocb;
                    ssize_t done = transfer->size_of_request;
                    dbg_tfr ("Freeing (async I/O request) last transfer %p, iocb %p\n", transfer, transfer->iocb);
                    transfer_destroy (engine->lro, transfer);
                    transfer = NULL;
                    dbg_tfr ("Completing async I/O iocb %p with size %d\n", iocb, (int)done);
                    /* indicate I/O completion XXX res, res2 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,1,0)
                    aio_complete (iocb, done, 0);
#else
                    iocb->ki_complete (iocb, done, 0);
#endif
                    /* synchronous I/O? */
                }
                else {
                    /* awake task on transfer's wait queue */
                    wake_up_interruptible (&transfer->wq);
                }
            }
        }

        /* engine stopped? */
        if (!engine->running) {
            /* engine was requested to be shutdown? */
            if (engine->shutdown & ENGINE_SHUTDOWN_REQUEST) {
                engine->shutdown |= ENGINE_SHUTDOWN_IDLE;
                /* awake task on engine's shutdown wait queue */
                wake_up_interruptible (&engine->shutdown_wq);
                /* more pending transfers? */
            }
            else if (!list_empty (&engine->transfer_list)) {
                /* (re)start engine */
                transfer_started = engine_start (engine);
                dbg_tfr ("re-started %s engine with pending transfer 0x%p\n",
                         engine->name, transfer_started);
            }
            else {
                dbg_tfr ("no pending transfers, %s engine remains idle.\n", engine->name);
            }
            /* engine is still running? */
        }
        else {
            if (list_empty (&engine->transfer_list)) {
                dbg_tfr ("no transfers on queue but %s engine is running?! cyclic?!\n", engine->name);
                WARN_ON (1);
            }
        }
        /* engine did not complete a transfer */
    }
    else {
        dbg_tfr ("%s engine triggered unknown interrupt 0x%08x\n", engine->name, engine->status);
    }
    /* remember last lock holder */
    engine->prev_cpu = cpu;
    return 0;
}

/* engine_service_work */
static void engine_service_work (struct work_struct *work) {
    struct xdma_engine *engine;
    engine = container_of (work, struct xdma_engine, work);
    BUG_ON (engine->magic != MAGIC_ENGINE);

    /* lock the engine */
    spin_lock (&engine->lock);
    /* C2H streaming? */
    if (engine->rx_transfer_cyclic) {
        printk (KERN_INFO "engine_service_cyclic() for %s engine %p\n", engine->name, engine);
        engine_service_cyclic (engine);
        /* no C2H streaming, default */
    }
    else {
        dbg_tfr ("engine_service_work() for %s engine %p\n", engine->name, engine);
        engine_service (engine);
    }

    /* re-enable interrupts for this engine */
    interrupts_enable (engine->lro, XDMA_OFS_INT_CTRL, engine->irq_bitmask);
    /* unlock the engine */
    spin_unlock (&engine->lock);
}

void engine_alignments (struct xdma_engine *engine) {
    u32 w;
    u32 align_bytes;
    u32 granularity_bytes;
    u32 address_bits;

    w = read_register (&engine->regs->alignments);
    dbg_init ("engine %p name %s alignments=0x%08x\n", engine, engine->name, (int)w);

    align_bytes = (w & 0x00ff0000U) >> 16;
    granularity_bytes = (w & 0x0000ff00U) >> 8;
    address_bits = (w & 0x000000ffU);

    printk (KERN_INFO "align_bytes = %d\n", align_bytes);
    printk (KERN_INFO "granularity_bytes = %d\n", granularity_bytes);
    printk (KERN_INFO "address_bits = %d\n", address_bits);

    if (w) {
        engine->addr_align = align_bytes;
        engine->len_granularity = granularity_bytes;
        engine->addr_bits = address_bits;
    }
}

/* engine_create() - Create an SG DMA engine bookkeeping data structure
 *
 * An SG DMA engine consists of the resources for a single-direction transfer
 * queue; the SG DMA hardware, the software queue and interrupt handling.
 *
 * @dev Pointer to pci_dev
 * @offset byte address offset in BAR[XDMA_BAR_XDMA] resource for the SG DMA
 * controller registers.
 * @dir_to_dev Whether the engine transfers to the device (PCIe Rd).
 * @streaming Whether the engine is attached to AXI ST (rather than MM)
 */
static struct xdma_engine *engine_create (struct xdma_dev *lro, int offset, int sgdma_offset, int dir_to_dev, int channel, int number_in_channel, int streaming) {
    /* allocate data structure for engine book keeping */
    struct xdma_engine *engine = kzalloc (sizeof (struct xdma_engine), GFP_KERNEL);

    /* memory allocation failure? */
    if (!engine) {
        return NULL;
    }

    /* set magic */
    engine->magic = MAGIC_ENGINE;

    /* indices */
    engine->channel = channel;
    engine->number_in_channel = number_in_channel;

    /* engine interrupt request bit */
    engine->irq_bitmask = (1 << XDMA_ENG_IRQ_NUM) - 1;
    engine->irq_bitmask <<= (lro->engines_num * XDMA_ENG_IRQ_NUM);

    lro->engines_num++;

    /* create virtual memory mapper */
    engine->sgm = sg_create_mapper (XDMA_TRANSFER_MAX_BYTES);

    if (!engine->sgm) {
        printk (KERN_INFO "sg_create_mapper(%d) failed\n", XDMA_TRANSFER_MAX_BYTES);
        goto fail_mapper;
    }

    /* initialize spinlock */
    spin_lock_init (&engine->lock);
    /* initialize transfer_list */
    INIT_LIST_HEAD (&engine->transfer_list);
    /* parent */
    engine->lro = lro;
    /* register address */
    engine->regs = (lro->bar[XDMA_BAR_XDMA] + offset);
    engine->sgdma_regs = (lro->bar[XDMA_BAR_XDMA] + sgdma_offset);
    /* remember SG DMA direction */
    engine->dir_to_dev = dir_to_dev;
    engine->streaming = streaming;
    engine->name = engine->dir_to_dev ? "H2C" : "C2H";

    dbg_init ("engine %p name %s irq_bitmask=0x%08x\n", engine, engine->name, (int)engine->irq_bitmask);

    /* initialize the deferred work for transfer completion */
    INIT_WORK (&engine->work, engine_service_work);
    /* initialize wait queue */
    init_waitqueue_head (&engine->shutdown_wq);
    /* initialize wait queue */
    init_waitqueue_head (&engine->xdma_perf_wq);

    write_register (XDMA_CTRL_NON_INCR_ADDR, &engine->regs->control_w1c);

    /* default is 1 byte alignment */
    engine->addr_align = 1;
    engine->len_granularity = 1;
    engine->addr_bits = 64;
    engine_alignments (engine);

    /* enable interrupts AXI ST C2H case */
    if (streaming && !dir_to_dev) {
        write_register (XDMA_CTRL_IE_DESCRIPTOR_STOPPED |
                        XDMA_CTRL_IE_DESCRIPTOR_COMPLETED |
                        XDMA_CTRL_IE_DESCRIPTOR_ALIGN_MISMATCH |
                        XDMA_CTRL_IE_MAGIC_STOPPED |
                        // Disable IDLE_STOPPED
                        XDMA_CTRL_IE_IDLE_STOPPED |
                        XDMA_CTRL_IE_READ_ERROR |
                        XDMA_CTRL_IE_DESCRIPTOR_ERROR, &engine->regs->interrupt_enable_mask);
    }
    else {
        // MM don't enable IDLE_STOP
        write_register (XDMA_CTRL_IE_DESCRIPTOR_STOPPED |
                        XDMA_CTRL_IE_DESCRIPTOR_COMPLETED |
                        XDMA_CTRL_IE_DESCRIPTOR_ALIGN_MISMATCH |
                        XDMA_CTRL_IE_MAGIC_STOPPED |
                        // Disable IDLE_STOPPED
                        //XDMA_CTRL_IE_IDLE_STOPPED |
                        XDMA_CTRL_IE_READ_ERROR |
                        XDMA_CTRL_IE_DESCRIPTOR_ERROR, &engine->regs->interrupt_enable_mask);
    }

    goto success;

fail_mapper:
    kfree (engine);
    engine = NULL;

success:
    return engine;
}





//=============
// descriptors
//=============

static void dump_desc (struct xdma_desc *desc_virt) {
    int j;
    u32 *p = (u32 *)desc_virt;
    const char *field_name[] = { "magic|extra_adjacent|control", "bytes",
                                 "src_addr_lo", "src_addr_hi", "dst_addr_lo", "dst_addr_hi",
                                 "next_addr", "next_addr_pad"
                               };

    for (j = 0; j < 8; j += 1) {
        dbg_desc ("0x%08lx/0x%02x: 0x%08x 0x%08x %s\n",
                  (int)p, (int)p & 15, *p, le32_to_cpu (*p), field_name[j]);
        p++;
    }

    dbg_desc ("\n");
}

static void transfer_dump (struct xdma_transfer *transfer) {
    int i;
    struct xdma_desc *desc_virt = transfer->desc_virt;
    dbg_desc ("Descriptor Entry (Pre-Transfer)\n");
    for (i = 0; i < transfer->desc_num; i += 1) {
        dump_desc (desc_virt + i);
    }
}

/* xdma_desc_alloc() - Allocate cache-coherent array of N descriptors.
 *
 * Allocates an array of 'number' descriptors in contiguous PCI bus addressable
 * memory. Chains the descriptors as a singly-linked list; the descriptor's next
 * pointer specifies the bus address of the next descriptor.
 *
 *
 * @dev Pointer to pci_dev
 * @number Number of descriptors to be allocated
 * @desc_bus_p Pointer where to store the first descriptor bus address
 * @desc_last_p Pointer where to store the last descriptor virtual address,
 * or NULL.
 *
 * @return Virtual address of the first descriptor
 *
 */
static struct xdma_desc *xdma_desc_alloc (struct pci_dev *dev, int number, dma_addr_t *desc_bus_p, struct xdma_desc **desc_last_p) {
    /* virtual address */
    struct xdma_desc *desc_virt;
    /* bus address */
    dma_addr_t desc_bus;
    int i, adj = number - 1, extra_adj;

    BUG_ON (number < 1);

    /* allocate a set of cache-coherent contiguous pages */
    desc_virt = (struct xdma_desc *)pci_alloc_consistent (dev,
                number * sizeof (struct xdma_desc), desc_bus_p);

    if (!desc_virt) {
        return NULL;
    }

    /* get bus address of the first descriptor */
    desc_bus = *desc_bus_p;
    WARN_ON ((desc_bus >> 16) >> 16);

    /* create singly-linked list for SG DMA controller */
    for (i = 0; i < number - 1; i++) {
        /* increment bus address to next in array */
        desc_bus += sizeof (struct xdma_desc);
        /* XXX assert not using >4GB addresses for descriptors XXX */
        WARN_ON ((desc_bus >> 16) >> 16);

        /* singly-linked list uses bus addresses */
        desc_virt[i].next_lo = cpu_to_le32 (pci_dma_l (desc_bus));
        desc_virt[i].next_hi = cpu_to_le32 (pci_dma_h (desc_bus));
        desc_virt[i].bytes = cpu_to_le32 (0);

        /* any adjacent descriptors? */
        if (adj > 0) {
            {
                extra_adj = adj - 1;
            }
            if (extra_adj > MAX_EXTRA_ADJ) {
                extra_adj = MAX_EXTRA_ADJ;
            }
            adj--;
        }
        else {
            extra_adj = 0;
        }

#if DESC_COUNTER
        desc_virt[i].control = cpu_to_le32 (0xAD4B0000UL |
                                            ((i & 0xf) << 12) | (extra_adj << 8));
#else
        desc_virt[i].control = cpu_to_le32 (0xAD4B0000UL | (extra_adj << 8));
#endif

    }

    /* { i = number - 1 } */
    /* zero the last descriptor next pointer */
    desc_virt[i].next_lo = cpu_to_le32 (0);
    desc_virt[i].next_hi = cpu_to_le32 (0);
    desc_virt[i].bytes = cpu_to_le32 (0);

#if DESC_COUNTER
    desc_virt[i].control = cpu_to_le32 (0xAD4B0000UL | ((i & 0xf) << 12));
#else
    desc_virt[i].control = cpu_to_le32 (0xAD4B0000UL);
#endif

    /* caller wants a pointer to last descriptor? */
    if (desc_last_p) {
        *desc_last_p = desc_virt + i;
    }

    /* return the virtual address of the first descriptor */
    return desc_virt;
}

/* xdma_desc_link() - Link two descriptors
 *
 * Link the first descriptor to a second descriptor, or terminate the first.
 *
 * @first first descriptor
 * @second second descriptor, or NULL if first descriptor must be set as last.
 * @second_bus bus address of second descriptor
 */
static void xdma_desc_link (struct xdma_desc *first, struct xdma_desc *second, dma_addr_t second_bus) {
    /* remember reserved control in first descriptor, but zero extra_adjacent! */
    u32 control = le32_to_cpu (first->control) & 0x0000f0ffUL;
    /* second descriptor given? */
    if (second) {
        /* link last descriptor of 1st array to first descriptor of 2nd array */
        first->next_lo = cpu_to_le32 (pci_dma_l (second_bus));
        first->next_hi = cpu_to_le32 (pci_dma_h (second_bus));
        WARN_ON (first->next_hi);
        /* no second descriptor given */
    }
    else {
        /* first descriptor is the last */
        first->next_lo = 0;
        first->next_hi = 0;
    }

    /* merge magic, extra_adjacent and control field */
    control |= 0xAD4B0000UL;

    /* write bytes and next_num */
    first->control = cpu_to_le32 (control);
}

/* makes an existing transfer cyclic */
static void xdma_transfer_cyclic (struct xdma_transfer *transfer) {
    /* link last descriptor to first descriptor */
    xdma_desc_link (transfer->desc_virt + transfer->desc_num - 1,
                    transfer->desc_virt, transfer->desc_bus);
    /* remember transfer is cyclic */
    transfer->cyclic = 1;
}

/* xdma_desc_adjacent -- Set how many descriptors are adjacent to this one */
static void xdma_desc_adjacent (struct xdma_desc *desc, int next_adjacent) {
    int extra_adj = 0;
    /* remember reserved and control bits */
    u32 control = le32_to_cpu (desc->control) & 0x0000f0ffUL;
    if (next_adjacent > 0) {
        extra_adj =  next_adjacent - 1;
        if (extra_adj > MAX_EXTRA_ADJ) {
            extra_adj = MAX_EXTRA_ADJ;
        }
    }
    /* merge adjacent and control field */
    control |= 0xAD4B0000UL | (extra_adj << 8);
    /* write control and next_adjacent */
    desc->control = cpu_to_le32 (control);
}

/* xdma_desc_control -- Set complete control field of a descriptor. */
static void xdma_desc_control (struct xdma_desc *first, u32 control_field) {
    /* remember magic and adjacent number */
    u32 control = le32_to_cpu (first->control) & 0xffffff00UL;
    BUG_ON (control_field & 0xffffff00UL);
    /* merge adjacent and control field */
    control |= control_field;
    /* write control and next_adjacent */
    first->control = cpu_to_le32 (control);
}

/* xdma_desc_clear -- Clear bits in control field of a descriptor. */
static void xdma_desc_control_clear (struct xdma_desc *first, u32 clear_mask) {
    /* remember magic and adjacent number */
    u32 control = le32_to_cpu (first->control);
    BUG_ON (clear_mask & 0xffffff00UL);
    /* merge adjacent and control field */
    control &= (~clear_mask);
    /* write control and next_adjacent */
    first->control = cpu_to_le32 (control);
}

/* xdma_desc_clear -- Set bits in control field of a descriptor. */
static void xdma_desc_control_set (struct xdma_desc *first, u32 set_mask) {
    /* remember magic and adjacent number */
    u32 control = le32_to_cpu (first->control);
    BUG_ON (set_mask & 0xffffff00UL);
    /* merge adjacent and control field */
    control |= set_mask;
    /* write control and next_adjacent */
    first->control = cpu_to_le32 (control);
}


/* xdma_desc_free - Free cache-coherent linked list of N descriptors.
 *
 * @dev Pointer to pci_dev
 * @number Number of descriptors to be allocated
 * @desc_virt Pointer to (i.e. virtual address of) first descriptor in list
 * @desc_bus Bus address of first descriptor in list
 */
static void xdma_desc_free (struct pci_dev *dev,
                            int number, struct xdma_desc *desc_virt, dma_addr_t desc_bus) {
    BUG_ON (!desc_virt);
    BUG_ON (number < 0);
    /* free contiguous list */
    pci_free_consistent (dev, number * sizeof (struct xdma_desc),
                         desc_virt, desc_bus);
}

/* xdma_desc() - Fill a descriptor with the transfer details
 *
 * @desc pointer to descriptor to be filled
 * @addr root complex address
 * @ep_addr end point address
 * @len number of bytes, must be a (non-negative) multiple of 4.
 * @dir_to_dev If non-zero, source is root complex address and destination
 * is the end point address. If zero, vice versa.
 *
 * Does not modify the next pointer
 */
static void xdma_desc_set (struct xdma_desc *desc, dma_addr_t rc_bus_addr, u64 ep_addr, int len, int dir_to_dev) {
    /* transfer length */
    desc->bytes = cpu_to_le32 (len);
    if (dir_to_dev) {
        /* read from root complex memory (source address) */
        desc->src_addr_lo = cpu_to_le32 (pci_dma_l (rc_bus_addr));
        desc->src_addr_hi = cpu_to_le32 (pci_dma_h (rc_bus_addr));
        /* write to end point address (destination address) */
        desc->dst_addr_lo = cpu_to_le32 (pci_dma_l (ep_addr));
        desc->dst_addr_hi = cpu_to_le32 (pci_dma_h (ep_addr));
    }
    else {
        /* read from end point address (source address) */
        desc->src_addr_lo = cpu_to_le32 (pci_dma_l (ep_addr));
        desc->src_addr_hi = cpu_to_le32 (pci_dma_h (ep_addr));
        /* write to root complex memory (destination address) */
        desc->dst_addr_lo = cpu_to_le32 (pci_dma_l (rc_bus_addr));
        desc->dst_addr_hi = cpu_to_le32 (pci_dma_h (rc_bus_addr));
    }
}

static void xdma_desc_set_source (struct xdma_desc *desc, u64 source) {
    /* read from end point address (source address) */
    desc->src_addr_lo = cpu_to_le32 (pci_dma_l (source));
    desc->src_addr_hi = cpu_to_le32 (pci_dma_h (source));
}





//==========
// transfer
//==========

static void transfer_set_result_addresses (struct xdma_transfer *transfer, u64 result_bus) {
    int i;
    /* iterate over transfer descriptor list */
    for (i = 0; i < transfer->desc_num; i++) {
        /* set the result ptr in source */
        xdma_desc_set_source (transfer->desc_virt + i, result_bus);
        result_bus += sizeof (struct xdma_result);
    }
}

static void transfer_set_all_control (struct xdma_transfer *transfer, u32 control) {
    int i;
    for (i = 0; i < transfer->desc_num; i++) {
        xdma_desc_control_clear (transfer->desc_virt + i,  0xFF);
        xdma_desc_control_set (transfer->desc_virt + i, control);
    }
}

/* transfer_queue() - Queue a DMA transfer on the engine
 *
 * @engine DMA engine doing the transfer
 * @transfer DMA transfer submitted to the engine
 *
 * Takes and releases the engine spinlock
 */
static int transfer_queue (struct xdma_engine *engine, struct xdma_transfer *transfer) {
    int rc = 0;
    struct xdma_transfer *transfer_started;
    BUG_ON (!engine);
    BUG_ON (!transfer);
    BUG_ON (transfer->desc_num == 0);
    dbg_tfr ("transfer_queue(transfer=0x%p).\n", transfer);

    /* lock the engine state */
    spin_lock (&engine->lock);
    engine->prev_cpu = get_cpu ();
    put_cpu ();

    /* engine is being shutdown; do not accept new transfers */
    if (engine->shutdown & ENGINE_SHUTDOWN_REQUEST) {
        rc = -1;
        goto shutdown;
    }

    /* either the engine is still busy and we will end up in the
     * service handler later, or the engine is idle and we have to
     * start it with this transfer here */

#if CHAIN_MULTIPLE_TRANSFERS
    /* queue is not empty? try to chain the descriptor lists */
    if (!list_empty (&engine->transfer_list)) {
        struct xdma_transfer *last;
        dbg_tfr ("transfer_queue(): list not empty\n");
        /* get last transfer queued on the engine */
        last = list_entry (engine->transfer_list.prev,
                           struct xdma_transfer, entry);
        /* @only when non-cyclic transfer */
        /* link the last transfer's last descriptor to this transfer */
        xdma_desc_link (last->desc_virt + last->desc_num - 1,
                        transfer->desc_virt, transfer->desc_bus);
        /* do not stop now that there is a linked transfers */
        xdma_desc_control_clear (last->desc_virt + last->desc_num - 1, XDMA_DESC_STOP);

        dbg_tfr ("transfer_queue(transfer=0x%p, desc=%d) chained after 0x%p with engine %s.\n",
                 transfer, transfer->desc_num, last, engine->running ? "running" : "idle");
        /* queue is empty */
    }
    else {
        if (engine->running) {
            dbg_tfr ("transfer_queue(): queue empty, but engine seems to be running?!!\n");
        }
        else {
            dbg_tfr ("transfer_queue(): queue empty and engine idle.\n");
        }
        /* engine should not be running */
        WARN_ON (engine->running);
    }
#endif

    /* mark the transfer as submitted */
    transfer->state = TRANSFER_STATE_SUBMITTED;
    /* add transfer to the tail of the engine transfer queue */
    list_add_tail (&transfer->entry, &engine->transfer_list);

    /* engine is idle? */
    if (!engine->running) {
        /* start engine */
        dbg_tfr ("transfer_queue(): starting %s engine.\n", engine->name);
        transfer_started = engine_start (engine);
        dbg_tfr ("transfer_queue(transfer=0x%p) started %s engine with transfer 0x%p.\n", transfer, engine->name, transfer_started);
    }
    else {
        dbg_tfr ("transfer_queue(transfer=0x%p) queued, with %s engine running.\n", transfer, engine->name);
    }

shutdown:
    /* unlock the engine state */
    dbg_tfr ("engine->running = %d\n", engine->running);
    spin_unlock (&engine->lock);
    return rc;
};

/* transfer_destroy() - free transfer */
static void transfer_destroy (struct xdma_dev *lro, struct xdma_transfer *transfer) {
    /* user space buffer was locked in on account of transfer? */
    if (transfer->sgm) {
        /* unmap scatterlist */
        //dbg_tfr("transfer_destroy(): pci_unmap_sg()\n");
        /* the direction is needed to synchronize caches */
        pci_unmap_sg (lro->pci_dev, transfer->sgm->sgl, transfer->sgm->mapped_pages,
                      transfer->dir_to_dev ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
        if (transfer->userspace) {
            /* dirty and unlock the pages */
            sgm_put_user_pages (transfer->sgm, transfer->dir_to_dev ? 0 : 1);
            //dbg_tfr("transfer_destroy(): sgm_put_user_pages()\n");
        }
        transfer->sgm->mapped_pages = 0;
        sg_destroy_mapper (transfer->sgm);
    }

    /* free descriptors */
    xdma_desc_free (lro->pci_dev, transfer->sgl_nents, transfer->desc_virt, transfer->desc_bus);

    /* free transfer */
    kfree (transfer);
}

/* transfer_create_user() - Create a DMA transfer to/from a user space buffer
 *
 * Allocates a transfer data structure and an array of descriptors. Builds a
 * descriptor list from the scatter gather list, coalescing adjacent entries.
 *
 * The scatterlist must have been mapped by pci_map_sg(sgm->sgl).
 *
 * @sgl scatterlist.
 * @nents Number of entries in the scatterlist after mapping by pci_map_sg().
 * @first Start index in the scatterlist sgm->sgl.
 *
 * Returns Number of entries in the table on success, -1 on error.
 */
static struct xdma_transfer *transfer_create_user (struct xdma_dev *lro, const char *start, size_t count, u64 ep_addr, int dir_to_dev) {
    int i = 0, j = 0, new_desc, rc;
    dma_addr_t cont_addr, addr;
    unsigned int cont_len, len, cont_max_len = 0;
    struct scatterlist *sgl;

    /* allocate transfer data structure */
    struct xdma_transfer *transfer =
        kzalloc (sizeof (struct xdma_transfer), GFP_KERNEL);

    dbg_sg ("transfer_create_user()\n");

    if (!transfer) {
        return NULL;
    }

    /* remember direction of transfer */
    transfer->dir_to_dev = dir_to_dev;

    /* create virtual memory mapper */
    transfer->sgm = sg_create_mapper (count);
    BUG_ON (!transfer->sgm);
    transfer->userspace = 1;

    /* lock user pages in memory and create a scatter gather list */
    rc = sgm_get_user_pages (transfer->sgm, start, count, !dir_to_dev);
    BUG_ON (rc < 0);

    sgl = transfer->sgm->sgl;

    dbg_sg ("mapped_pages=%d.\n", transfer->sgm->mapped_pages);
    dbg_sg ("sgl = 0x%p.\n", transfer->sgm->sgl);
    BUG_ON (!lro->pci_dev);
    BUG_ON (!transfer->sgm->sgl);
    BUG_ON (!transfer->sgm->mapped_pages);
    /* map all SG entries into DMA memory */
    transfer->sgl_nents = pci_map_sg (lro->pci_dev, transfer->sgm->sgl,
                                      transfer->sgm->mapped_pages, dir_to_dev ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
    dbg_sg ("hwnents=%d.\n", transfer->sgl_nents);

    /* verify if the page start address got into the first sg entry */
    dbg_sg ("sg_page(&sgl[0])=0x%p.\n", sg_page (&transfer->sgm->sgl[0]));
    dbg_sg ("sg_dma_address(&sgl[0])=0x%016llx.\n", (u64)sg_dma_address (&transfer->sgm->sgl[0]));
    dbg_sg ("sg_dma_len(&sgl[0])=0x%08x.\n", sg_dma_len (&transfer->sgm->sgl[0]));

    /* allocate descriptor list */
    transfer->desc_virt = xdma_desc_alloc (lro->pci_dev,
                                           transfer->sgl_nents, &transfer->desc_bus, NULL);
    WARN_ON ((transfer->desc_bus >> 16) >> 16);
    dbg_sg ("transfer_create_user():\n");
    dbg_sg ("transfer->desc_bus = 0x%llx.\n", (u64)transfer->desc_bus);

    /* start first contiguous block */
    cont_addr = addr = sg_dma_address (&transfer->sgm->sgl[i]);
    cont_len = 0;

    /* iterate over all remaining entries but the last */
    for (i = 0; i < transfer->sgl_nents - 1; i++) {
        /* bus address of next entry i + 1 */
        dma_addr_t next = sg_dma_address (&sgl[i + 1]);
        /* length of this entry i */
        len = sg_dma_len (&sgl[i]);
        dbg_desc ("SGLE %04d: addr=0x%016llx length=0x%08x\n", i, (u64)addr, len);

        /* add entry i to current contiguous block length */
        cont_len += len;

        new_desc = 0;
        /* entry i + 1 is non-contiguous with entry i? */
        if (next != addr + len) {
            dbg_desc ("NON-CONTIGUOUS WITH DESC %d\n", i + 1);
            new_desc = 1;
        }
        /* entry i reached maximum transfer size? */
        else if (cont_len > (XDMA_DESC_MAX_BYTES - PAGE_SIZE)) {
            dbg_desc ("BREAK\n");
            new_desc = 1;
        }

        if (new_desc) {
            /* fill in descriptor entry j with transfer details */
            xdma_desc_set (transfer->desc_virt + j, cont_addr,
                           ep_addr, cont_len, dir_to_dev);
#if FORCE_IR_DESC_COMPLETED
            xdma_desc_control (transfer->desc_virt + j, XDMA_DESC_COMPLETED);
#endif
            if (cont_len > cont_max_len) {
                cont_max_len = cont_len;
                dbg_desc ("LONGEST CONTIGUOUS LENGTH (SO FAR) = %d\n",
                          cont_max_len);
            }
            dbg_desc ("DESC %4d: cont_addr=0x%016llx cont_len=0x%08x, ep_addr=0x%llx\n",
                      j, (u64)cont_addr, cont_len, (unsigned long long)ep_addr);
            /* proceed EP address for next contiguous block */
            ep_addr += cont_len;
            /* start new contiguous block */
            cont_addr = next;
            cont_len = 0;
            j++;
        }

        /* goto entry i + 1 */
        addr = next;
    }

    /* i is the last entry in the scatterlist, add it to the last block */
    len = sg_dma_len (&sgl[i]);
    cont_len += len;
    BUG_ON (j > transfer->sgl_nents);

    /* j is the index of the last descriptor */

    dbg_desc ("SGLE %04d: addr=0x%016llx length=0x%08x\n", i, (u64)addr, len);
    dbg_desc ("DESC %4d: cont_addr=0x%016llx cont_len=0x%08x, ep_addr=0x%llx\n",
              j, (u64)cont_addr, cont_len, (unsigned long long)ep_addr);

    /* XXX to test error condition, set cont_len = 0 */

    /* fill in last descriptor entry j with transfer details */
    xdma_desc_set (transfer->desc_virt + j, cont_addr,
                   ep_addr, cont_len, dir_to_dev);

#if XDMA_PERFORMANCE_TEST
    /* create a linked loop */
    xdma_desc_link (transfer->desc_virt + j, transfer->desc_virt, transfer->desc_bus);
#  if FORCE_IR_DESC_COMPLETED
    /* request IRQ on last descriptor */
    xdma_desc_control (transfer->desc_virt + j, XDMA_DESC_COMPLETED);
#  endif
#else
    /* terminate last descriptor */
    xdma_desc_link (transfer->desc_virt + j, 0, 0);
    /* stop engine, EOP for AXI ST, and request IRQ on last descriptor */
    xdma_desc_control (transfer->desc_virt + j, XDMA_DESC_STOP | XDMA_DESC_EOP | XDMA_DESC_COMPLETED);
#endif

    j++;
    /* j is the number of descriptors */
    transfer->desc_num = transfer->desc_adjacent = j;

    dbg_sg ("transfer 0x%p has %d descriptors\n", transfer, transfer->desc_num);
    /* fill in adjacent numbers */
    for (i = 0; i < transfer->desc_num; i++) {
        xdma_desc_adjacent (transfer->desc_virt + i,
                            transfer->desc_num - i - 1);
    }

    /* initialize wait queue */
    init_waitqueue_head (&transfer->wq);

    return transfer;
}

/* transfer_create_kernel() - Create a DMA transfer to/from a kernel buffer
 *
 * Allocates a transfer data structure and an array of descriptors. Builds a
 * descriptor list from the scatter gather list, coalescing adjacent entries.
 *
 * The scatterlist must have been mapped by pci_map_sg(sgm->sgl).
 *
 * vmalloc_to_pfn
 *
 * @sgl scatterlist.
 * @nents Number of entries in the scatterlist after mapping by pci_map_sg().
 * @first Start index in the scatterlist sgm->sgl.
 *
 * Returns Number of entries in the table on success, -1 on error.
 */
static struct xdma_transfer *transfer_create_kernel (struct xdma_dev *lro, const char *start, size_t count, u64 ep_addr, int dir_to_dev, int force_new_desc) {
    int i = 0, j = 0, new_desc, rc;
    dma_addr_t cont_addr, addr;
    unsigned int cont_len, len, cont_max_len = 0;
    struct scatterlist *sgl;

    /* allocate transfer data structure */
    struct xdma_transfer *transfer =
        kzalloc (sizeof (struct xdma_transfer), GFP_KERNEL);

    printk (KERN_INFO "transfer_create_kernel()\n");

    if (!transfer) {
        return NULL;
    }

    /* remember direction of transfer */
    transfer->dir_to_dev = dir_to_dev;

    /* create virtual memory mapper */
    transfer->sgm = sg_create_mapper (count);
    BUG_ON (!transfer->sgm);

    /* create a scatter gather list */
    rc = sgm_kernel_pages (transfer->sgm, start, count, !dir_to_dev);
    BUG_ON (rc < 0);

    sgl = transfer->sgm->sgl;

    dbg_sg ("mapped_pages=%d.\n", transfer->sgm->mapped_pages);
    dbg_sg ("sgl = 0x%p.\n", transfer->sgm->sgl);
    BUG_ON (!lro->pci_dev);
    BUG_ON (!transfer->sgm->sgl);
    BUG_ON (!transfer->sgm->mapped_pages);
    /* map all SG entries into DMA memory */
    transfer->sgl_nents = pci_map_sg (lro->pci_dev, transfer->sgm->sgl,
                                      transfer->sgm->mapped_pages, dir_to_dev ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
    dbg_sg ("hwnents=%d.\n", transfer->sgl_nents);

    /* verify if the page start address got into the first sg entry */
    dbg_sg ("sg_page(&sgl[0])=0x%p.\n", sg_page (&transfer->sgm->sgl[0]));
    dbg_sg ("sg_dma_address(&sgl[0])=0x%016llx.\n", (u64)sg_dma_address (&transfer->sgm->sgl[0]));
    dbg_sg ("sg_dma_len(&sgl[0])=0x%08x.\n", sg_dma_len (&transfer->sgm->sgl[0]));

    /* allocate descriptor list */
    transfer->desc_virt = xdma_desc_alloc (lro->pci_dev,
                                           transfer->sgl_nents, &transfer->desc_bus, NULL);
    dbg_sg ("transfer_create_user():\n");
    dbg_sg ("transfer->desc_bus = 0x%llx.\n", (u64)transfer->desc_bus);

    /* start first contiguous block */
    cont_addr = addr = sg_dma_address (&transfer->sgm->sgl[i]);
    cont_len = 0;

    /* iterate over all remaining entries but the last */
    for (i = 0; i < transfer->sgl_nents - 1; i++) {
        /* bus address of next entry i + 1 */
        dma_addr_t next = sg_dma_address (&sgl[i + 1]);
        /* length of this entry i */
        len = sg_dma_len (&sgl[i]);
        dbg_desc ("SGLE %04d: addr=0x%016llx length=0x%08x\n", i, (u64)addr, len);

        /* add entry i to current contiguous block length */
        cont_len += len;

        new_desc = 0;

        /* entry i + 1 is non-contiguous with entry i? */
        if (next != addr + len) {
            dbg_desc ("NON CONTIGUOUS\n");
            new_desc = 1;
        }
        /* entry i reached maximum transfer size? */
        else if (cont_len > (XDMA_DESC_MAX_BYTES - PAGE_SIZE)) {
            dbg_desc ("BREAK\n");
            new_desc = 1;
        }

        if (force_new_desc) {
            new_desc = 1;
        }

        if (new_desc) {
            /* fill in descriptor entry j with transfer details */
            xdma_desc_set (transfer->desc_virt + j, cont_addr,
                           ep_addr, cont_len, dir_to_dev);

#if FORCE_IR_DESC_COMPLETED
            xdma_desc_control (transfer->desc_virt + j, XDMA_DESC_COMPLETED);
#endif

            if (cont_len > cont_max_len) {
                cont_max_len = cont_len;
                dbg_desc ("DESC %4d: cont_addr=0x%016llx cont_len=0x%08x, ep_addr=0x%llx\n",
                          j, (u64)cont_addr, cont_len, (unsigned long long)ep_addr);
            }

            dbg_desc ("DESC %4d: cont_addr=0x%016llx cont_len=0x%08x, ep_addr=0x%llx\n",
                      j, (u64)cont_addr, cont_len, (unsigned long long)ep_addr);

            /* proceed EP address for next contiguous block */
            ep_addr += cont_len;
            /* start new contiguous block */
            cont_addr = next;
            cont_len = 0;
            j++;
        }

        /* goto entry i + 1 */
        addr = next;
    }

    /* i is the last entry in the scatterlist, add it to the last block */
    len = sg_dma_len (&sgl[i]);
    cont_len += len;
    BUG_ON (j > transfer->sgl_nents);

    /* j is the index of the last descriptor */

    dbg_desc ("SGLE %04d: addr=0x%016llx length=0x%08x\n", i, (u64)addr, len);
    dbg_desc ("DESC %4d: cont_addr=0x%016llx cont_len=0x%08x, ep_addr=0x%llx\n",
              j, (u64)cont_addr, cont_len, (unsigned long long)ep_addr);

    /* XXX to test error condition, set cont_len = 0 */

    /* fill in last descriptor entry j with transfer details */
    xdma_desc_set (transfer->desc_virt + j, cont_addr,
                   ep_addr, cont_len, dir_to_dev);
    /* terminate last descriptor */
    xdma_desc_link (transfer->desc_virt + j, 0, 0);
    /* request IRQ on last descriptor */
    xdma_desc_control (transfer->desc_virt + j, XDMA_DESC_STOP | XDMA_DESC_EOP | XDMA_DESC_COMPLETED);

    j++;
    /* j is the number of descriptors */
    transfer->desc_num = transfer->desc_adjacent = j;

    dbg_sg ("transfer 0x%p has %d descriptors\n", transfer, transfer->desc_num);

    /* fill in adjacent numbers */
    for (i = 0; i < transfer->desc_num; i++) {
        xdma_desc_adjacent (transfer->desc_virt + i,
                            transfer->desc_num - i - 1);
    }

    /* initialize wait queue */
    init_waitqueue_head (&transfer->wq);

    return transfer;
}





//================
// scatter-gather
//================

/* char_sgdma_read_write() -- Read from or write to the device
 *
 * @buf userspace buffer
 * @count number of bytes in the userspace buffer
 * @pos byte-address in device
 * @dir_to_device If !0, a write to the device is performed
 *
 * Iterate over the userspace buffer, taking at most 255 * PAGE_SIZE bytes for
 * each DMA transfer.
 *
 * For each transfer, get the user pages, build a sglist, map, build a
 * descriptor table. submit the transfer. wait for the interrupt handler
 * to wake us on completion.
 */
ssize_t char_sgdma_read_write (struct xdma_dev *lro, struct xdma_sgdma_ioctl *sgdma_opt, int dir_to_dev) {
    int rc;
    ssize_t res = 0;
    static int counter = 0;
    int seq = counter++;
    ssize_t remaining = (ssize_t)sgdma_opt->length, done = 0;
    char *transfer_addr = (char *)sgdma_opt->buffer;
    char *buf = (char *)sgdma_opt->buffer;
    unsigned long long count = sgdma_opt->length;
    unsigned long long pos = sgdma_opt->addr_offset;
    struct xdma_char *lro_char;
    struct xdma_engine *engine;

    engine = lro->engine[sgdma_opt->channel][sgdma_opt->engine];

    // detect non-supported directions
    BUG_ON (!engine);
    BUG_ON (engine->magic != MAGIC_ENGINE);

    dbg_tfr ("seq:%d char_sgdma_read_write(lro=0x%p, buf=0x%p, count=%lld, pos=%llu, dir_to_dev=%d) %s request\n",
             seq, lro, buf, (s64)count, (u64)pos, dir_to_dev, dir_to_dev ? "write" : "read");
    dbg_tfr ("%s engine channel %d (engine num %d)= 0x%p\n", engine->name, engine->channel, engine->number_in_channel, engine);
    dbg_tfr ("lro = 0x%p\n", lro);

    /* data direction does not match engine? */
    if (dir_to_dev != engine->dir_to_dev) {
        if (dir_to_dev) {
            printk (KERN_INFO "FAILURE: Cannot write to C2H engine.\n");
        }
        else {
            printk (KERN_INFO "FAILURE: Cannot read from H2C engine.\n");
        }
        return -EINVAL;
    }

    // AXI ST or AXI MM non-incremental addressing mode?
    if (engine->streaming || engine->non_incr_addr) {
        int buf_lsb = (int) buf & (engine->addr_align - 1);
        size_t len_lsb = count & ((size_t)engine->len_granularity - 1);
        int pos_lsb = (int)pos & (engine->addr_align - 1);

        printk (KERN_DEBUG "AXI ST or MM non-incremental: buf_lsb = %d, pos_lsb = %d, len_lsb = %d\n",
                buf_lsb, pos_lsb, (int) len_lsb);

        if (buf_lsb != 0) {
            printk (KERN_INFO "FAILURE: non-aligned host buffer address %p\n", buf);
            return -EINVAL;
        }
        if ((!engine->streaming) && (pos_lsb != 0)) {
            printk (KERN_INFO "FAILURE: non-aligned AXI MM FPGA address 0x%llx\n", (unsigned long long)pos);
            return -EINVAL;
        }
        if (len_lsb != 0) {
            printk (KERN_INFO "FAILURE: length %d is not a multiple of %d\n", (int) count, (int) engine->len_granularity);
            return -EINVAL;
        }
    }
    // AXI MM incremental addressing mode
    else {
        int buf_lsb = (int) buf & (engine->addr_align - 1);
        int pos_lsb = (int) pos & (engine->addr_align - 1);

        //printk (KERN_DEBUG "AXI MM incrementbuf_lsb = %d, pos_lsb = %d\n", buf_lsb, pos_lsb);

        if (buf_lsb != pos_lsb) {
            printk (KERN_INFO "FAILURE: host buffer address %p is not aligned to FPGA address %p\n",
                    (int *)buf, (int *)pos);
            return -EINVAL;
        }
    }

    remaining = count;

    dbg_tfr ("res = %d, remaining = %d\n", res, remaining);

    // still good and anything left to transfer?
    while ((res == 0) && (remaining > 0)) {
        struct xdma_transfer *transfer;

        // DMA transfer size, multiple if necessary
        size_t transfer_len = (remaining > XDMA_TRANSFER_MAX_BYTES) ?
                              XDMA_TRANSFER_MAX_BYTES : remaining;

        // build device-specific descriptor tables
        transfer = transfer_create_user (lro, transfer_addr, transfer_len, pos, dir_to_dev);

        dbg_tfr ("seq:%d transfer=0x%p.\n", seq, transfer);
        BUG_ON (!transfer);

        if (!transfer) {
            remaining = 0;
            res = -EIO;
            continue;
        }

        transfer_dump (transfer);

        /* last transfer for the given request? */
        if (transfer_len >= remaining) {
            transfer->last_in_request = 1;
            transfer->size_of_request = done + transfer_len;
        }

        /* let the device read from the host */
        transfer_queue (engine, transfer);

        /* the function servicing the engine will wake us */
        rc = wait_event_interruptible (transfer->wq, transfer->state != TRANSFER_STATE_SUBMITTED);
        if (rc) {
            dbg_tfr ("seq:%d wait_event_interruptible() = %d\n", seq, rc);
        }

        /* transfer was taken off the engine? */
        if (transfer->state != TRANSFER_STATE_SUBMITTED) {
            /* transfer failed? */
            if (transfer->state != TRANSFER_STATE_COMPLETED) {
                dbg_tfr ("transfer %p failed\n", transfer);
                transfer_len = remaining = 0;
                res = -EIO;
            }
            dbg_tfr ("transfer %p completed\n", transfer);
            transfer_destroy (lro, transfer);
            /* wait_event_interruptible() was interrupted by a signal? */
        }
        else if (rc == -ERESTARTSYS) {
            dbg_tfr ("wait_event_interruptible(transfer->wq) == ERESTARTSYS\n");
            /* transfer can still be in-flight */
            engine_status_read (engine, 0);
            read_interrupts (lro, XDMA_OFS_INT_CTRL);
            transfer_len = remaining = 0;

            dbg_tfr ("waiting for transfer 0x%p to complete.\n", transfer);
            dbg_tfr ("transfer 0x%p has completed, transfer->state = %d\n", transfer, transfer->state);

            res = -ERESTARTSYS;
            if (transfer->state != TRANSFER_STATE_SUBMITTED) {
                transfer_destroy (lro, transfer);
            }
        }

        /* calculate the next transfer */
        transfer_addr += transfer_len;
        remaining -= transfer_len;
        done += transfer_len;
        pos += transfer_len;
        dbg_tfr ("remaining = %lld, done = %lld.\n",
                 (s64)remaining, (s64)done);
    }

    /* return error or else number of bytes */
    res = res ? res : done;
    dbg_tfr ("seq:%d char_sgdma_read_write() returns %lld.\n", seq, (s64)res);
    engine_status_read (engine, 0);

#if XDMA_STATUS_DUMPS
    interrupt_status (lro);
#endif

    return res;
}

ssize_t char_sgdma_read_cyclic (struct xdma_dev *lro, struct xdma_sgdma_ioctl *sgdma_opt, int dir_to_dev) {
    int rc;
    char *buf = (char *)sgdma_opt->buffer;
    unsigned long long count = sgdma_opt->length;
    unsigned long long pos = sgdma_opt->addr_offset;
    struct xdma_char *lro_char;
    struct xdma_engine *engine;
    struct xdma_transfer *transfer;
    struct xdma_result *result;

    int head;
    int eop = 0;
    int packet_length = 0;

    engine = lro->engine[sgdma_opt->channel][sgdma_opt->engine];
    /* XXX detect non-supported directions XXX */
    BUG_ON (!engine);
    BUG_ON (engine->magic != MAGIC_ENGINE);

    transfer = engine->rx_transfer_cyclic;
    BUG_ON (!transfer);

    result = (struct xdma_result *)engine->rx_result_buffer_virt;
    BUG_ON (!result);

    dbg_tfr ("char_sgdma_read_cyclic()");

    result = (struct xdma_result *)engine->rx_result_buffer_virt;
    /* wait for result at head pointer */
    while (result[engine->rx_head].status == 0) {
        rc = wait_event_interruptible (transfer->wq, result[engine->rx_head].status != 0);
        if (rc) {
            dbg_tfr ("char_sgdma_read_cyclic(): wait_event_interruptible() = %d\n", rc);
            return rc;
        }
    }

    spin_lock (&engine->lock);

    /* overrun condition? */
    if (engine->rx_overrun) {
        /* reset overrun flag */
        engine->rx_overrun = 0;
        spin_unlock (&engine->lock);
        /* report overrun */
        return -EIO;
    }

    /* where the host currently is in the ring buffer */
    head = engine->rx_head;
    /* iterate over newly received results */
    while (result[engine->rx_head].status) {
        int fault = 0;
        dbg_tfr ("result[engine->rx_head=%3d].status = 0x%08x, rx->length = %d\n",
                 engine->rx_head, (int)result[engine->rx_head].status, (int)result[engine->rx_head].length);

        /* overrun occurs when the tail is incremented and then matches head, not here */
        if (engine->rx_head == engine->rx_tail) {
            printk (KERN_DEBUG "engine->rx_head == engine->rx_tail, breaking out.");
            break;
        }
        else {
            if ((result[engine->rx_head].status >> 16) != 0x52b4) {
                printk (KERN_DEBUG "engine->rx_head has no result magic 0x52b4");
                fault = 1;
            }
            else if (result[engine->rx_head].length > 4096) {
                printk (KERN_DEBUG "engine->rx_head length exceeds 4096 bytes");
                fault = 1;
            }
            else if (result[engine->rx_head].length == 0) {
                printk (KERN_DEBUG "engine->rx_head length is zero bytes");
                fault = 1;
                /* valid result */
            }
            else {
                packet_length += result[engine->rx_head].length;
                /* seen eop? */
                if (result[engine->rx_head].status & RX_STATUS_EOP) {
                    dbg_tfr ("char_sgdma_read_cyclic(): packet_length = %d (with EOP)\n", packet_length);
                    eop = 1;
                }
                else {
                    dbg_tfr ("char_sgdma_read_cyclic(): packet_length = %d (ongoing, no EOP yet)\n", packet_length);
                }
            }
        }

        /* clear result */
        result[engine->rx_head].status = 0;
        result[engine->rx_head].length = 0;
        /* proceed head pointer so we make progress, even when fault */
        engine->rx_head = (engine->rx_head + 1) % RX_BUF_PAGES;
        /* unexpected result */
        if (fault) {
            printk (KERN_DEBUG "char_sgdma_read_cyclic() fault %d\n", fault);
            spin_unlock (&engine->lock);
            return -EIO;
        }
        /* end-of-packet flag, exit the loop */
        if (eop) {
            break;
        }
    }

    spin_unlock (&engine->lock);
    /* EOP found? Transfer anything from head to EOP */
    if (eop) {
        int remaining = packet_length;
        int done = 0;
        while (remaining) {
            int copy = remaining > 4096 ? 4096 : remaining;
            dbg_tfr ("char_sgdma_read_cyclic(): copy %d bytes from %p to %p\n", copy, (void *)&engine->rx_buffer[head * 4096], (void *)&buf[done]);
            copy_to_user (&buf[done], &engine->rx_buffer[head * 4096], copy);
            remaining -= copy;
            done += copy;
            head = (head + 1) % RX_BUF_PAGES;
        }
    }
    else {
        packet_length = 0;
    }

    dbg_tfr ("char_sgdma_read_cyclic() returns %d\n", packet_length);
    return packet_length;
}

/*
 * Called when the device goes from unused to used.
 */
static int char_sgdma_open (struct inode *inode, struct file *file) {
    int rc = 0, i, j;
    int dir_from_dev, channel;
    int channel_id, engine_id, value;
    struct xdma_char *lro_char;
    struct xdma_dev *lro;
    struct xdma_engine *engine;
    struct engine_regs *regs;

    /* pointer to containing data structure of the character device inode */
    lro_char = container_of (inode->i_cdev, struct xdma_char, cdev);
    BUG_ON (lro_char->magic != MAGIC_CHAR);

    /* create a reference to our char device in the opened file */
    file->private_data = lro_char;

    lro = lro_char->lro;
    BUG_ON (!lro);
    BUG_ON (lro->magic != MAGIC_DEVICE);

    dbg_tfr ("char_sgdma_open(0x%p, 0x%p)\n", inode, file);

    /* iterate over H2C (PCIe read), then C2H (PCIe write) */
    for (dir_from_dev = 0; dir_from_dev < 2; dir_from_dev++) {
        /* iterate over channels */
        for (channel = 0; channel < XDMA_CHANNEL_NUM_MAX; channel++) {

            /* read channels at 0x0000, write channels at 0x1000, channels at 0x100 interval */
            int offset = (dir_from_dev * 0x1000U) + (channel * 0x100U);
            int sgdma_offset = 0;

            regs = lro->bar[XDMA_BAR_XDMA] + offset;
            /* read identifier/version */
            value = ioread32 (&regs->identifier);
            dbg_init ("Found Engine ID register value 0x%08x\n", value);

            engine_id = (value & 0xffff0000U) >> 16;
            channel_id = (value & 0x00000f00U) >> 8;
            if ((value & 0xfff00000U) != 0x1fc00000U) {
                dbg_init ("Found Engine ID 0x%08x, skipping as it is unknown.\n", value);
                continue;
            }
            engine = lro->engine[channel][dir_from_dev];

            /* atomically set up ring buffer */
            spin_lock (&engine->lock);

            /* AXI ST C2H? Set up a receive ring buffer on the host with a cyclic transfer */
            if (engine->streaming && !engine->dir_to_dev) {
                engine->rx_tail = 0;
                engine->rx_head = 0;
                engine->rx_overrun = 0;
                if (engine->rx_buffer) {
                    printk (KERN_INFO "Channel is already open, cannot be opened twice.\n");
                    rc = -EBUSY;
                    goto fail_in_use;
                }
                engine->rx_buffer = rvmalloc (RX_BUF_SIZE);
                if (engine->rx_buffer == NULL) {
                    printk (KERN_INFO "rvmalloc(%d) failed\n", RX_BUF_SIZE);
                    goto fail_buffer;
                }
                printk (KERN_INFO "engine->rx_buffer = %p\n", engine->rx_buffer);
                engine->rx_transfer_cyclic = transfer_create_kernel (lro, engine->rx_buffer, RX_BUF_SIZE, 0, engine->dir_to_dev, 1);
                if (engine->rx_buffer == NULL) {
                    printk (KERN_INFO "transfer_create_kernel(%d) failed\n", RX_BUF_SIZE);
                    goto fail_transfer;
                }
                engine->rx_result_buffer_virt = pci_alloc_consistent (lro->pci_dev, RX_BUF_PAGES * sizeof (struct xdma_result), &engine->rx_result_buffer_bus);
                if (engine->rx_result_buffer_virt == NULL) {
                    printk (KERN_INFO "pci_alloc_consistent(%d) failed\n", RX_BUF_SIZE);
                    goto fail_result_buffer;
                }
                dbg_init ("engine->rx_result_buffer_virt = %p\n", engine->rx_result_buffer_virt);
                dbg_init ("engine->rx_result_buffer_bus = %p\n", engine->rx_result_buffer_bus);
                /* replace source addresses with result write-back addresses */
                transfer_set_result_addresses (engine->rx_transfer_cyclic, engine->rx_result_buffer_bus);
                /* set control of all descriptors */
                transfer_set_all_control (engine->rx_transfer_cyclic, XDMA_DESC_EOP | XDMA_DESC_COMPLETED);
                /* make this a cyclic transfer */
                xdma_transfer_cyclic (engine->rx_transfer_cyclic);
                transfer_dump (engine->rx_transfer_cyclic);
                /* for streaming engines, allow only one user, allocate kernel buffer here */
                spin_unlock (&engine->lock);

                /* start cyclic transfer */
                if (engine->rx_transfer_cyclic) {
                    transfer_queue (engine, engine->rx_transfer_cyclic);
                }
                continue;
            }

            /* for streaming engines, allow only one user, allocate kernel buffer here */
            spin_unlock (&engine->lock);

            continue;

            /* unwind on errors */
fail_result_buffer:
            transfer_destroy (engine->lro, engine->rx_transfer_cyclic);
            engine->rx_transfer_cyclic = NULL;
fail_transfer:
            rvfree (engine->rx_buffer, RX_BUF_SIZE);
            engine->rx_buffer = NULL;
fail_buffer:
fail_in_use:
            /* for streaming engines, allow only one user, allocate kernel buffer here */
            spin_unlock (&engine->lock);
            for (i = 0; i <= dir_from_dev; i++) {
                for (j = 0; j < channel; j++) {
                    engine = lro->engine[j][i];

                    /* atomically set up ring buffer */
                    spin_lock (&engine->lock);
                    if (engine->rx_transfer_cyclic) {
                        transfer_destroy (engine->lro, engine->rx_transfer_cyclic);
                        engine->rx_transfer_cyclic = NULL;
                    }
                    if (engine->rx_buffer) {
                        rvfree (engine->rx_buffer, RX_BUF_SIZE);
                        engine->rx_buffer = NULL;
                    }
                    if (engine->rx_result_buffer_virt) {
                        /* free contiguous list */
                        pci_free_consistent (lro->pci_dev, RX_BUF_PAGES * sizeof (struct xdma_result), engine->rx_result_buffer_virt, engine->rx_result_buffer_bus);
                        engine->rx_result_buffer_virt = NULL;
                    }
                    /* for streaming engines, allow only one user, allocate kernel buffer here */
                    spin_unlock (&engine->lock);
                }
            }
        }
    }
    return rc;
}

/*
 * Called when the device goes from used to unused.
 */
static int char_sgdma_close (struct inode *inode, struct file *file) {
    int dir_from_dev;
    int channel;
    struct xdma_char *lro_char = (struct xdma_char *)file->private_data;
    struct xdma_dev *lro;
    struct xdma_engine *engine;
    BUG_ON (!lro_char);
    BUG_ON (lro_char->magic != MAGIC_CHAR);

    /* fetch device specific data stored earlier during open */
    lro = lro_char->lro;
    BUG_ON (!lro);
    BUG_ON (lro->magic != MAGIC_DEVICE);

    dbg_tfr ("char_sgdma_close(0x%p, 0x%p)\n", inode, file);

    /* iterate over H2C (PCIe read), then C2H (PCIe write) */
    for (dir_from_dev = 0; dir_from_dev < 2; dir_from_dev++) {
        /* iterate over channels */
        for (channel = 0; channel < XDMA_CHANNEL_NUM_MAX; channel++) {
            engine = lro->engine[channel][dir_from_dev];

            if (engine == NULL) {
                continue;
            }

            /* atomically stop and destroy cyclic transfer */
            spin_lock (&engine->lock);

            if (engine->streaming && !engine->dir_to_dev) {
                int rc;
                struct xdma_transfer *transfer = engine_cyclic_stop (engine);
                if (transfer) {
                    dbg_tfr ("char_sgdma_close() stopped transfer %p\n", transfer);
                    if (transfer != engine->rx_transfer_cyclic) {
                        dbg_tfr ("char_sgdma_close() unexpected transfer %p vs engine->rx_transfer_cyclic = %p\n",
                                 transfer, engine->rx_transfer_cyclic);
                    }
                }
                /* allow engine to be serviced after stop request */
                spin_unlock (&engine->lock);
                /* wait for engine to be no longer running */
                rc = wait_event_interruptible (engine->shutdown_wq, !engine->running);
                if (rc) {
                    dbg_tfr ("char_sgdma_close(): wait_event_interruptible(engine->shutdown_wq) = %d\n", rc);
                    return rc;
                }
                if (engine->running) {
                    dbg_tfr ("char_sgdma_close(): engine still running?!\n");
                    return -EINVAL;
                }
                dbg_tfr ("char_sgdma_close(): wait_event_interruptible(engine->shutdown_wq) = %d\n", rc);

                /* obtain spin lock to atomically remove resources */
                spin_lock (&engine->lock);

                if (engine->rx_transfer_cyclic) {
                    transfer_destroy (engine->lro, engine->rx_transfer_cyclic);
                    engine->rx_transfer_cyclic = NULL;
                }
                if (engine->rx_buffer) {
                    rvfree (engine->rx_buffer, RX_BUF_SIZE);
                    engine->rx_buffer = NULL;
                }
                if (engine->rx_result_buffer_virt) {
                    /* free contiguous list */
                    pci_free_consistent (lro->pci_dev, RX_BUF_PAGES * sizeof (struct xdma_result), engine->rx_result_buffer_virt, engine->rx_result_buffer_bus);
                    engine->rx_result_buffer_virt = NULL;
                }
            }
            spin_unlock (&engine->lock);
        }
    }
    return 0;
}

/*
 * character device file operations for SG DMA engine
 */
static struct file_operations sg_fops = {
    .owner = THIS_MODULE,
    .open = char_sgdma_open,
    .release = char_sgdma_close,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
    .ioctl = char_sgdma_ioctl,
#else
    .unlocked_ioctl = char_sgdma_ioctl,
#endif
};

static int destroy_sg_char (struct xdma_char *lro_char) {
    BUG_ON (!lro_char);
    BUG_ON (lro_char->magic != MAGIC_CHAR);
    BUG_ON (!lro_char->lro);
    BUG_ON (!g_xdma_class);
    BUG_ON (!lro_char->sys_device);
    if (lro_char->sys_device) {
        device_destroy (g_xdma_class, lro_char->cdevno);
    }
    cdev_del (&lro_char->cdev);
    unregister_chrdev_region (lro_char->cdevno, 1/*count*/);
    kfree (lro_char);
    return 0;
}

#define XDMA_MINOR_BASE (0)
#define XDMA_MINOR_COUNT (255)

/* create_char() -- create a character device interface to data or control bus
 *
 * If at least one SG DMA engine is specified, the character device interface
 * is coupled to the SG DMA file operations which operate on the data bus. If
 * no engines are specified, the interface is coupled with the control bus.
 */
static struct xdma_char *create_sg_char (struct xdma_dev *lro) {
    struct xdma_char *lro_char;
    int rc;
    int minor;

    //static const char *names = "xdma_driver%d";
    printk (KERN_DEBUG DRV_NAME " create_sg_char(lro = 0x%p)\n", lro);
    /* at least one engine must be specified */
    //BUG_ON(!read_engine && !write_engine);
    /* allocate book keeping data structure */
    lro_char = kzalloc (sizeof (struct xdma_char), GFP_KERNEL);
    if (!lro_char) {
        return NULL;
    }
    lro_char->magic = MAGIC_CHAR;

    /* new instance? */
    if (lro->major == 0) {
        int i = 0;

        // find first free instance number
        while ((dev_present[i] == 1) && (i < MAX_XDMA_DEVICES)) {
            i++;
        }

        if (i == MAX_XDMA_DEVICES) {
            printk (KERN_DEBUG "Device limit reached\n");
            goto fail_alloc;
        }

        dev_present[i] = 1;
        lro->instance = i;

        /* dynamically pick a number into cdevno */
        if (major == 0) {
            /* allocate a dynamically allocated character device node */
            rc = alloc_chrdev_region (&lro_char->cdevno, XDMA_MINOR_BASE,
                                      XDMA_MINOR_COUNT, DRV_NAME);
            /* remember */
            lro->major = MAJOR (lro_char->cdevno);
            printk (KERN_DEBUG "Dynamically allocated major %d, rc = %d\n", lro->major, rc);
            /* major number given, calculate minor into cdevno */
        }
        else {
            lro->major = major--;
            printk (KERN_DEBUG "Reusing allocated major %d\n", lro->major);
        }
    }

    /* minor number is type index for non-SGDMA interfaces */
    minor = 0;

    lro_char->cdevno = MKDEV (lro->major, minor);
    /* do not register yet, create kobjects and name them,
     * re-use the name during single-minor registration */

    /* are we dealing with a SG DMA character device interface? */
    /* couple the SG DMA device file operations to the character device */
    cdev_init (&lro_char->cdev, &sg_fops);
    printk (KERN_DEBUG DRV_NAME "dev= %d:%d\n", MAJOR (lro_char->cdevno), MINOR (lro_char->cdevno));

    /* user character device interface? */
    lro_char->cdev.owner = THIS_MODULE;

    rc = 0;
    if (major) {
        rc = kobject_set_name (&lro_char->cdev.kobj, names, lro->instance);
        WARN_ON (rc);
        printk (KERN_INFO "register_chrdev_region(%s)\n", lro_char->cdev.kobj.name);
        rc = register_chrdev_region (lro_char->cdevno, 1, lro_char->cdev.kobj.name);
    }

    if (rc < 0) {
        printk (KERN_INFO "register_chrdev_region()=%d failed.\n", rc);
        goto fail_alloc;
    }

    /* remember parent */
    lro_char->lro = lro;

    /* bring character device live */
    rc = cdev_add (&lro_char->cdev, lro_char->cdevno, XDMA_MINOR_COUNT);
    if (rc < 0) {
        printk (KERN_DEBUG "cdev_add() = %d\n", rc);
        goto fail_add;
    }
    /* create device on our class */
    if (g_xdma_class) {
        /* this must match the enumeration of CHAR_ */
        //static const char *name = "xdma_driver%d";

        lro_char->sys_device = device_create (g_xdma_class,
                                              &lro->pci_dev->dev, lro_char->cdevno, NULL/*driver data*/,
                                              names, 0);
        if (!lro_char->sys_device) {
            printk (KERN_DEBUG "device_create(%s) failed\n", names);
            goto fail_device;
        }
    }

    goto success;
fail_device:
    cdev_del (&lro_char->cdev);
fail_add:
    unregister_chrdev_region (lro_char->cdevno, XDMA_MINOR_COUNT);
fail_alloc:
    kfree (lro_char);
    lro_char = NULL;
success:
    return lro_char;
}





//===============
// kernel module
//===============

static int __devinit probe (struct pci_dev *pdev, const struct pci_device_id *id) {
    int rc = 0;
    u16 dcr;
    u32 value;
    int dir_from_dev;
    int channel;
    struct xdma_dev *lro = NULL;
    struct engine_regs *regs;
    struct engine_sgdma_regs *sgdma_regs;
    printk (KERN_DEBUG "probe(pdev = 0x%p, pci_id = 0x%p)\n", pdev, id);

    /* allocate zeroed device book keeping structure */
    lro = kzalloc (sizeof (struct xdma_dev), GFP_KERNEL);
    if (!lro) {
        printk (KERN_DEBUG "Could not kzalloc(xdma_dev).\n");
        goto err_alloc;
    }
    lro->magic = MAGIC_DEVICE;
    /* create a device to driver reference */
    dev_set_drvdata (&pdev->dev, lro);
    /* create a driver to device reference */
    lro->pci_dev = pdev;
    printk (KERN_DEBUG "probe() lro = 0x%p\n", lro);

    /* initialize spinlock for atomically changing events_irq */
    spin_lock_init (&lro->events_lock);
    /* initialize wait queue for events */
    init_waitqueue_head (&lro->events_wq);

    printk (KERN_DEBUG "pci_indevice()\n");
    rc = pci_enable_device (pdev);
    if (rc) {
        printk (KERN_DEBUG "pci_enable_device() failed, rc = %d.\n", rc);
        goto err_enable;
    }

    /* enable bus master capability */
    printk (KERN_DEBUG "pci_set_master()\n");
    pci_set_master (pdev);

    if (msi) {
        int i;
        int req_nvec = 32;
        /* enable message signaled interrupts */
        printk (KERN_DEBUG "pci_enable_msi()\n");
        rc = pci_enable_msi (pdev);
        if (rc < 0) {
            printk (KERN_DEBUG "Could not enable MSI interrupting; rc = %d.\n", rc);
            rc = -1;
            goto err_msi;
        }
        lro->msi_enabled = 1;
    }

    /* known root complex's max read request sizes */
#ifdef CONFIG_ARCH_TI816X
    printk (KERN_DEBUG "TI816X RC detected: limiting MaxReadReq size to 128 bytes.\n");
    pcie_set_readrq (pdev, 128);
#endif

    printk (KERN_DEBUG "pci_request_regions()\n");
    rc = pci_request_regions (pdev, DRV_NAME);
    /* could not request all regions? */
    if (rc) {
        printk (KERN_DEBUG "pci_request_regions() = %d, device in use?\n", rc);
        /* assume device is in use so do not disable it later */
        lro->regions_in_use = 1;
        goto err_regions;
    }
    lro->got_regions = 1;

    printk (KERN_DEBUG "map_bars()\n");
    /* map BARs */
    rc = map_bars (lro, pdev);
    if (rc) {
        goto err_map;
    }

    xdma_config (lro, 0x3000);

    printk ("sizeof(dma_addr_t) == %ld\n", sizeof (dma_addr_t));
    /* 64-bit addressing capability for XDMA? */
    if (!pci_set_dma_mask (pdev, DMA_BIT_MASK (64))) {
        /* query for DMA transfer */
        /* @see Documentation/DMA-mapping.txt */
        printk (KERN_DEBUG "pci_set_dma_mask()\n");
        /* use 64-bit DMA */
        printk (KERN_DEBUG "Using a 64-bit DMA mask.\n");
        /* use 32-bit DMA for descriptors */
        pci_set_consistent_dma_mask (pdev, DMA_BIT_MASK (32));
        /* use 64-bit DMA, 32-bit for consistent */
    }
    else if (!pci_set_dma_mask (pdev, DMA_BIT_MASK (32))) {
        printk (KERN_DEBUG "Could not set 64-bit DMA mask.\n");
        pci_set_consistent_dma_mask (pdev, DMA_BIT_MASK (32));
        /* use 32-bit DMA */
        printk (KERN_DEBUG "Using a 32-bit DMA mask.\n");
    }
    else {
        printk (KERN_DEBUG "No suitable DMA possible.\n");
        /** @todo Choose proper error return code */
        rc = -1;
        goto err_mask;
    }

    lro->irq_line = -1;

    /* request irq, MSI interrupts are not shared */
    printk (KERN_DEBUG "request_irq()\n");
    rc = request_irq (pdev->irq, xdma_isr,
                      lro->msi_enabled ? 0 : IRQF_SHARED, DRV_NAME, (void *)lro);
    if (rc) {
        printk (KERN_DEBUG "Could not request IRQ #%d; rc = %d.\n",
                pdev->irq, rc);
        lro->irq_line = -1;
        goto err_irq;
    }
    /* remember the allocated irq */
    lro->irq_line = (int)pdev->irq;
    printk (KERN_DEBUG "Succesfully requested IRQ #%d with dev_id 0x%p\n",
            lro->irq_line, lro);

    /* iterate over H2C (PCIe read), then C2H (PCIe write) */
    for (dir_from_dev = 0; dir_from_dev < 2; dir_from_dev++) {
        int dir_to_dev = !dir_from_dev;
        int channel;
        /* iterate over channels */
        for (channel = 0; channel < XDMA_CHANNEL_NUM_MAX; channel++) {
            u32 engine_id;
            u32 channel_id;
            u32 version;
            /* register offset for the engine */
            /* read channels at 0x0000, write channels at 0x1000, channels at 0x100 interval */
            int offset = (dir_from_dev * 0x1000U) + (channel * 0x100U);
            int sgdma_offset = 0;
            int streaming = 0;
            /* SGDMA descriptor fetcher */
            sgdma_offset = offset;

#if USE_RTL_SGDMA_TARGET
            sgdma_offset += 0x4000U;
#endif
            regs = lro->bar[XDMA_BAR_XDMA] + offset;
            sgdma_regs = lro->bar[XDMA_BAR_XDMA] + sgdma_offset;
            printk (KERN_DEBUG "Probing for channel %d %s engine at %p\n", channel, dir_to_dev ? "H2C" : "C2H", regs);
            /* read identifier/version */
            value = ioread32 (&regs->identifier);
            dbg_init ("Found Engine ID register value 0x%08x\n", value);

            engine_id = (value & 0xffff0000U) >> 16;
            channel_id = (value & 0x00000f00U) >> 8;
            if ((value & 0xfff00000U) != 0x1fc00000U) {
                dbg_init ("Found Engine ID 0x%08x, skipping as it is unknown.\n", value);
                continue;
            }
            dbg_init ("Found Engine ID value 0x%08x\n", engine_id);
            /* Target Channel ID*/
            channel_id = (value & 0x00000f00U) >> 8;
            if (channel_id != channel) {
                printk (KERN_DEBUG "Expected channel ID %d , but read channel ID %d\n", channel, channel_id);
                continue;
            }

            value = ioread32 (&sgdma_regs->identifier);
            dbg_init ("Read SGDMA ID value   0x%08x\n", value);
            //printk(KERN_DEBUG "SGDMA  ID 0x%04x\n", (value & 0xffff0000U) >> 16);

            value = ioread32 (&regs->identifier);
            version = (value & 0x000000ffU);
            /* bit 15 indicates AXI ST */
            streaming = value & 0x8000U;
            /* no read engine identifier? */
            if (dir_to_dev) {
                if ((engine_id == XDMA_ID_H2C) && (channel_id == channel)) {
                    dbg_init ("Found channel %d H2C AXI %s engine at %p with identifier 0x%08x\n", channel, streaming ? "ST" : "MM", regs, (int)value);
                    /* allocate and initialize H2C engine */
                    lro->engine[channel][dir_from_dev] = engine_create (lro, offset, sgdma_offset, 1/*to_dev*/, channel, 0/*num_in_channel*/, streaming);
                    if (!lro->engine[channel][dir_from_dev]) {
                        goto err_engine;
                    }
                }
                else {
                    printk (KERN_DEBUG "No H2C engine at %p for channel %d, read 0x%08x\n", regs, channel, (int)value);
                    continue;
                }
            }
            else { /*!dir_to_dev*/
                if ((engine_id == XDMA_ID_C2H) && (channel_id == channel)) {
                    dbg_init ("Found channel %d C2H AXI %s engine at %p with identifier 0x%08x\n", channel, streaming ? "ST" : "MM", regs, (int)value);
                    /* allocate and initialize C2H engine */
                    lro->engine[channel][dir_from_dev] = engine_create (lro, offset, sgdma_offset, 0/*to_dev*/, channel, 1/*num_in_channel*/, streaming);
                    if (!lro->engine[channel][dir_from_dev]) {
                        goto err_engine;
                    }
                }
                else {
                    printk (KERN_DEBUG "No C2H engine at %p for channel %d, read 0x%08x\n", regs, channel, (int)value);
                    continue;
                }
            }
        }
    }

    /* initialize XDMA character device */
    lro->sgdma_char_dev = create_sg_char (lro);
    if (!lro->sgdma_char_dev) {
        printk (KERN_DEBUG "create_char(xdma_driver) failed\n");
        goto err_sgdma_cdev;
    }

    rc = interrupts_enable (lro, XDMA_OFS_INT_CTRL, 0x00ffffffUL);

    printk (KERN_DEBUG "Create device attribute file for major = %d, instance = %d\n", (int)lro->major, (int)lro->instance);
    rc = device_create_file (&pdev->dev, &dev_attr_xdma_dev_instance);
    if (rc) {
        printk (KERN_DEBUG "Failed to create device file \n");
        goto err_sgdma_cdev;
    }
    else {
        printk (KERN_DEBUG "Device file created sux\n");
    }

    rc = 0;
    if (rc == 0) {
        goto end;
    }

err_sgdma_cdev:
    /* destroy_engine */
    destroy_sg_char (lro->sgdma_char_dev);
    lro->sgdma_char_dev = NULL;
err_engine:
err_mask:
err_msi:
    /* disable the device only if it was not in use */
    if (!lro->regions_in_use) {
        pci_disable_device (pdev);
    }
    /* free allocated irq */
    if (lro->irq_line > -1) {
        free_irq (lro->irq_line, (void *)lro);
    }
err_irq:
err_system:
err_map:
    /* unmap the BARs */
    unmap_bars (lro, pdev);
    if (lro->got_regions) {
        pci_release_regions (pdev);
    }
err_regions:
    /* disable message signaled interrupts */
    if (lro->msi_enabled) {
        pci_disable_msi (pdev);
    }
err_rev:
//err_msi:
    //pci_disable_device(pdev);
    /* clean up everything before device enable() */
err_enable:
    kfree (lro);
err_alloc:
end:
    return rc;
}

static void __devexit remove (struct pci_dev *pdev) {
    int channel;
    struct xdma_dev *lro;
    printk (KERN_DEBUG "remove(0x%p)\n", pdev);
    if ((pdev == 0) || (dev_get_drvdata (&pdev->dev) == 0)) {
        printk (KERN_DEBUG
                "remove(dev = 0x%p) pdev->dev.driver_data = 0x%p\n",
                pdev, dev_get_drvdata (&pdev->dev));
        return;
    }
    lro = (struct xdma_dev *)dev_get_drvdata (&pdev->dev);
    printk (KERN_DEBUG
            "remove(dev = 0x%p) where pdev->dev.driver_data = 0x%p\n",
            pdev, lro);
    if (lro->pci_dev != pdev) {
        printk (KERN_DEBUG
                "pdev->dev.driver_data->pci_dev (0x%08lx) != pdev (0x%08lx)\n",
                (unsigned long)lro->pci_dev, (unsigned long)pdev);
    }

    /* remove SG DMA character device */

    destroy_sg_char (lro->sgdma_char_dev);
    lro->sgdma_char_dev = NULL;

    /* free IRQ */
    if (lro->irq_line >= 0) {
        printk (KERN_DEBUG "Freeing IRQ #%d for dev_id 0x%08lx.\n",
                lro->irq_line, (unsigned long)lro);
        free_irq (lro->irq_line, (void *)lro);
    }
    /* MSI was enabled? */
    if (lro->msi_enabled) {
        /* Disable MSI @see Documentation/MSI-HOWTO.txt */
        printk (KERN_DEBUG "Disabling MSI interrupting.\n");
        pci_disable_msi (pdev);
        lro->msi_enabled = 0;
    }
    /* unmap the BARs */
    unmap_bars (lro, pdev);
    printk (KERN_DEBUG "Unmapping BARs.\n");
    if (!lro->regions_in_use) {
        printk (KERN_DEBUG "Disabling device.\n");
        pci_disable_device (pdev);
    }
    if (lro->got_regions)
        /* to be called after pci_disable_device()! */
    {
        pci_release_regions (pdev);
    }

    // free instance number
    dev_present[lro->instance] = 0;
    device_remove_file (&pdev->dev, &dev_attr_xdma_dev_instance);
}


static struct pci_driver pci_driver = {
    .name = DRV_NAME,
    .id_table = pci_ids,
    .probe = probe,
    .remove = remove,
    /* resume, suspend are optional */
};

static int __init xdma_init (void) {
    int rc = 0, i;

    printk (KERN_INFO DRV_NAME " UltraScale PCI Express DMA Driver\n");
    printk (KERN_INFO DRV_NAME " built on " __DATE__ " " __TIME__ "\n");

    g_xdma_class = class_create (THIS_MODULE, DRV_NAME);

    if (IS_ERR (g_xdma_class)) {
        printk (KERN_DEBUG DRV_NAME ": failed to create class");
        rc = -1;
        return rc;
    }

    rc = pci_register_driver (&pci_driver);

    // init dev_present array. No devices present
    for (i = 0; i < MAX_XDMA_DEVICES; i++) {
        dev_present[i] = 0;
    }

    return rc;
}

static void __exit xdma_exit (void) {
    pci_unregister_driver (&pci_driver);

    if (g_xdma_class) {
        class_destroy (g_xdma_class);
    }

    printk (KERN_INFO DRV_NAME " exited\n");
}

module_init (xdma_init);
module_exit (xdma_exit);

