#include <linux/ioctl.h>
#include <linux/types.h>
#include <linux/cdev.h>
#include <linux/fb.h> /* frame buffer */
#include <linux/fs.h>
#include <linux/dma-mapping.h>
#include <linux/mm.h> /* mmap */
#include <linux/mm_types.h> /* mmap */

#include <linux/pci.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/workqueue.h>

/* kernel bug: linux/aio.h depends on linux/kobject.h linux/kdev_t.h,
 * but aio.h does not include these in some releases of the kernel. */
#include <linux/aio.h>
#include <linux/splice.h>

#include "xdma-sgm.h"
#include "xdma-ioctl.h"

/* testing purposes; request interrupt on each descriptor */
#define FORCE_IR_DESC_COMPLETED 0

#define XDMA_BAR_NUM (3)
#define XDMA_BAR_XDMA (1)

/* MMIO bridge */
#define USER_BAR (0)
/* MMIO bridge to XDMA components */
#define XDMA_BAR (1)
/* maximum amount of register space to map */
#define XDMA_BAR_SIZE (0x8000UL)
#define BYPASS_BAR (2)

#define XDMA_CHANNEL_NUM_MAX (4)
/* engines per channel */
#define XDMA_ENGINE_NUM (2)
/* interrupts per engine, rad2_vul.sv:237 .REG_IRQ_OUT  (reg_irq_from_ch[(channel*2) +: 2]), */
#define XDMA_ENG_IRQ_NUM (1)

#define CHAR_USER 0
#define CHAR_CTRL 1
#define CHAR_EVENTS 2
#define CHAR_BYPASS 3
#define CHAR_XDMA_H2C 4
#define CHAR_XDMA_C2H 5

#define MAGIC_ENGINE 0xEEEEEEEEUL
#define MAGIC_DEVICE 0xDDDDDDDDUL
#define MAGIC_CHAR 0xCCCCCCCCUL

/* dump XDMA FPGA status during operation */
#define XDMA_STATUS_DUMPS 0

/* maximum number of bytes per transfer request */
#define XDMA_TRANSFER_MAX_BYTES (2048 * 4096)

/* maximum size of a single DMA transfer descriptor; 1<<16 = 64 KB */
#define XDMA_DESC_MAX_BYTES ((1 << 18) - 1)

/** bits of the SG DMA control register */
#define XDMA_CTRL_RUN_STOP (1UL << 0)
#define XDMA_CTRL_IE_DESCRIPTOR_STOPPED (1UL << 1)
#define XDMA_CTRL_IE_DESCRIPTOR_COMPLETED (1UL << 2)
#define XDMA_CTRL_IE_DESCRIPTOR_ALIGN_MISMATCH (1UL << 3)
#define XDMA_CTRL_IE_MAGIC_STOPPED (1UL << 4)
#define XDMA_CTRL_IE_IDLE_STOPPED (1UL << 6)
#define XDMA_CTRL_IE_READ_ERROR (0x1FUL << 9)
#define XDMA_CTRL_IE_DESCRIPTOR_ERROR (0x1FUL << 19)
#define XDMA_CTRL_NON_INCR_ADDR (1UL << 25)
#define XDMA_CTRL_RST (1UL << 31)

/** bits of the SG DMA status register */
#define XDMA_STAT_BUSY (1UL << 0)
#define XDMA_STAT_DESCRIPTOR_STOPPED (1UL << 1)
#define XDMA_STAT_DESCRIPTOR_COMPLETED (1UL << 2)
#define XDMA_STAT_ALIGN_MISMATCH (1UL << 3)
#define XDMA_STAT_MAGIC_STOPPED (1UL << 4)
#define XDMA_STAT_FETCH_STOPPED (1UL << 5)
#define XDMA_STAT_IDLE_STOPPED (1UL << 6)
#define XDMA_STAT_READ_ERROR (0x1FUL << 9)
#define XDMA_STAT_DESCRIPTOR_ERROR (0x1FUL << 19)

/** bits of the SGDMA descriptor control field */
#define XDMA_DESC_STOP (1UL << 0)
#define XDMA_DESC_COMPLETED (1UL << 1)
#define XDMA_DESC_EOP (1UL << 4)

#define XDMA_PERF_RUN (1UL << 0)
#define XDMA_PERF_CLEAR (1UL << 1)
#define XDMA_PERF_AUTO (1UL << 2)

/* upper 16-bit of engine identifier register */
#define XDMA_ID_H2C 0x1fc0U
#define XDMA_ID_C2H 0x1fc1U
#define PERF_CTRL_RUN 1
#define PERF_CTRL_IE 2

#define PERF_STAT_BUSY 1
#define PERF_STAT_IRQ 2

#define TRANSFER_STATE_NEW 0
#define TRANSFER_STATE_SUBMITTED 1
#define TRANSFER_STATE_COMPLETED 3
#define TRANSFER_STATE_FAILED 4

#define MAX_XDMA_DEVICES 64

#define XDMA_DEBUG 0

#if (XDMA_DEBUG == 0)
// disable debugging
#define dbg_desc(...)
#define dbg_io(...)
#define dbg_perf(fmt, ...)
#define dbg_sg(...)
#define dbg_tfr(...)
#define dbg_irq(...)
#define dbg_init(...)
#define dbg_ioctl(...)
#else
// descriptor, ioread/write, scatter-gather, transfer debugging
#define dbg_desc(fmt, ...) printk(KERN_DEBUG fmt, ##__VA_ARGS__)
#define dbg_io(fmt, ...) printk(KERN_DEBUG fmt, ##__VA_ARGS__)
#define dbg_perf(fmt, ...) printk(KERN_DEBUG fmt, ##__VA_ARGS__)
#define dbg_sg(fmt, ...) printk(KERN_DEBUG fmt, ##__VA_ARGS__)
#define dbg_irq(fmt, ...) printk(KERN_INFO fmt, ##__VA_ARGS__)
#define dbg_init(fmt, ...) printk(KERN_INFO fmt, ##__VA_ARGS__)
#define dbg_ioctl(fmt, ...) printk(KERN_INFO fmt, ##__VA_ARGS__)
#define dbg_tfr(format, ...) do { \
    printk(KERN_INFO "%s%c: " format, engine? (engine->number_in_channel? "C2H": "H2C"): "---", engine? '0' + engine->channel: '-', ##__VA_ARGS__); \
} while(0)
#endif

#define write_register(value, iomem) iowrite32(value, iomem)
#define read_register(iomem) ioread32(iomem)



struct config_regs {
    /* identifier 0x4 */
    u32 identifier;
    u32 reserved_1[17];
    u32 align_gran_addr;
};

/**
 * SG DMA Controller status and control registers
 *
 * These registers make the control interface for DMA transfers.
 *
 * It sits in End Point (FPGA) memory BAR[0] for 32-bit or BAR[0:1] for 64-bit.
 * It references the first descriptor which exists in Root Complex (PC) memory.
 *
 * @note The registers must be accessed using 32-bit (PCI DWORD) read/writes,
 * and their values are in little-endian byte ordering.
 */
struct engine_regs {
    /* identifier 0x4 */
    u32 identifier;
    /* control register 0x8 */
    u32 control;
    /* control register 0xc */
    u32 control_w1s;
    /* control register 0x10 */
    u32 control_w1c;
    u32 reserved_1[12];

    /* status register { 6'h10, 2'b0 } is 0x40 */
    u32 status;
    u32 status_rc;
    /* number of completed descriptors */
    u32 completed_desc_count;
    /* alignments */
    u32 alignments;
    u32 reserved_2[12];
    u32 reserved_3[4];

    /* interrupt mask  { 6'h24, 2'b0 } is 0x90 */
    u32 interrupt_enable_mask;
    u32 interrupt_enable_mask_w1s;
    u32 interrupt_enable_mask_w1c;
    u32 reserved_4[9];

    /* interrupt mask  { 6'h30, 2'b0 } is 0xc0 */
    u32 perf_ctrl;
    u32 perf_cyc_lo;
    u32 perf_cyc_hi;
    u32 perf_dat_lo;
    u32 perf_dat_hi;
    u32 perf_pnd_lo;
    u32 perf_pnd_hi;
    //u32 completed_desc_bytes;
} __attribute__ ((packed));

struct engine_sgdma_regs {
    /* identifier 0x4 */
    u32 identifier;
    u32 reserved_1[31];

    /* bus address to first descriptor in Root Complex memory { 6'h20, 2'b0 } is 0x80 */
    u32 first_desc_lo;
    u32 first_desc_hi;
    /* number of adjacent descriptors at first_desc */
    u32 first_desc_adjacent;
} __attribute__ ((packed));

struct scratch_pad_regs {
    u32 scratch0;
    u32 scratch1;
    u32 scratch2;
    u32 scratch3;
    u32 scratch4;
    u32 scratch5;
    u32 scratch6;
    u32 scratch7;
} __attribute__ ((packed));

/* Performance counter for AXI Streaming
 */
struct performance_regs {
    /* identifier 0xc34900xx */
    u32 identifier;
    /* control register */
    u32 control;
    /* status register */
    u32 status;
    /* 64-bit period in 8 ns units (low 32-bit) */
    u32 period_low;
    /* period (high 32-bit) */
    u32 period_high;
    /* 64-bit performance counter in 8-byte units (low 32-bit) */
    u32 performance_low;
    /* performance (high 32-bit) */
    u32 performance_high;
    /* 64-bit wait counter in 8-byte units (low 32-bit) */
    u32 wait_low;
    /* wait (high 32-bit) */
    u32 wait_high;
} __attribute__ ((packed));

struct interrupt_regs {
    /* identifier */
    u32 identifier;
    u32 user_int_enable;
    u32 user_int_enable_w1s;
    u32 user_int_enable_w1c;

    u32 channel_int_enable;
    u32 channel_int_enable_w1s;
    u32 channel_int_enable_w1c;
    u32 reserved_1[9];

    u32 user_int_request;
    u32 channel_int_request;
    u32 user_int_pending;
    u32 channel_int_pending;
    u32 reserved_2[12];

    u32 user_msi_vector[8];
    u32 channel_msi_vector[8];
} __attribute__ ((packed));

/* Incremental data tester
 */
struct tester_regs {
    /* identifier 0xae2300xx */
    u32 identifier;
    /* control register */
    u32 control;
    /* status register */
    u32 status;
    /* counter register */
    u32 counter;
} __attribute__ ((packed));

struct xdma_packet_generator_regs {
    u32 control;
} __attribute__ ((packed));

struct xdma_latency_tester_regs {
    u32 id;
    u32 control;
    u32 status;
    u32 delay;
    u32 data;
    u32 counter;
} __attribute__ ((packed));

/**
 * Descriptor for a single contiguous memory block transfer.
 *
 * Multiple descriptors are linked by means of the next pointer. An additional
 * extra adjacent number gives the amount of extra contiguous descriptors.
 *
 * The descriptors are in root complex memory, and the bytes in the 32-bit
 * words must be in little-endian byte ordering.
 */
struct xdma_desc {
    /* descriptor control field (0 / 0x00) */
    u32 control;
    /* number of bytes in the transfer (1 / 0x04) */
    u32 bytes;
    /* source address */
    u32 src_addr_lo;
    u32 src_addr_hi;
    /* destination address */
    u32 dst_addr_lo;
    u32 dst_addr_hi;
    /* next descriptor in the single-linked list of descriptors;
     * this is the PCIe (bus) address of the next descriptor in the
     * root complex memory. */
    u32 next_lo;
    u32 next_hi;
} __attribute__ ((packed));

/* 32 bytes (four 32-bit words) or 64 bytes (eight 32-bit words) */
struct xdma_result {
    u32 status;
    u32 length;
    u32 reserved_1[6];
} __attribute__ ((packed));

/**
 * Describes a (SG DMA) single transfer for the engine.
 */
struct xdma_transfer {
#if 0
    struct xdma_dev *lro;
#endif
    /* queue of non-completed transfers */
    struct list_head entry;
    /* virtual address of the first descriptor */
    struct xdma_desc *desc_virt;
    /* bus address of the first descriptor */
    dma_addr_t desc_bus;
    /* number of descriptors adjacent in memory at desc_bus address */
    int desc_adjacent;
    /* number of descriptors involved in the transfer */
    int desc_num;
    /* whether the direction of the transfer is to the device */
    int dir_to_dev;
    /* wait queue for synchronously waiting threads */
    wait_queue_head_t wq;
    /* completion buffer for asynchronous I/O, NULL if not used */
    struct kiocb *iocb;
    /* number of descriptors at desc_virt address */
    int sgl_nents;
    /* user space scatter gather mapper, NULL if not used */
    struct sg_mapping_t *sgm;
    /* user space pages were gotten? */
    int userspace;
    /* state of the transfer */
    int state;
    /* cyclic transfer? */
    int cyclic;
    /* last transfer within an I/O request? */
    int last_in_request;
    /* last transfer within an I/O request? */
    ssize_t size_of_request;
};

struct xdma_engine {
    /* MAGIC_ENGINE == 0xEEEEEEEE */
    unsigned long magic;
    /* parent device */
    struct xdma_dev *lro;

    /* engine indices */
    int channel;
    int number_in_channel;

    /* character device major:minor */
    dev_t cdevno;
    /* character device (embedded struct) */
    struct cdev cdev;

    /* protects concurrent access interrupt context */
    spinlock_t lock;
    /* remember CPU# of (last) locker */
    int prev_cpu;
    /* queue of transfers */
    struct list_head transfer_list;

#define RX_BUF_PAGES 256
    /* for AXI ST, an in-kernel transfer with cyclic descriptor list is used */
#define RX_BUF_SIZE (RX_BUF_PAGES * 4096)
    int streaming;
    void *rx_buffer;
    struct xdma_transfer *rx_transfer_cyclic;
    u8 *rx_result_buffer_virt;
    /* bus address */
    dma_addr_t rx_result_buffer_bus;
    /* follows the RTL */
    int rx_tail;
    /* where the application reads from */
    int rx_head;
    int rx_overrun;

    /* if set, indicates non-incremental addressing mode */
    int non_incr_addr;

    /* alignment rules for both directions dir_to_dev = { 0, 1 } */
    int addr_align;
    int len_granularity;
    int addr_bits;

    /* address offset of the engine in its BAR */
    struct engine_regs *regs;
    struct engine_sgdma_regs *sgdma_regs;
    /* direction of this engine */
    int dir_to_dev;
    /* whether the driver has started the engine */
    int running;
    /* whether the engine stopped accepting new requests */
    int shutdown;
    /* engine requested to shutdown */
#define ENGINE_SHUTDOWN_REQUEST 1
    /* engine has been shutdown and is idle */
#define ENGINE_SHUTDOWN_IDLE 2
    /* stay idle preparing for driver unload */
#define ENGINE_SHUTDOWN_TEARDOWN 4
    /* wait queue for synchronously waiting threads */
    wait_queue_head_t shutdown_wq;
    /* last known status of device */
    u32 status;
#if 0
    /* last set control of device */
    u32 control;
#endif
    /* interrupt */
    u32 interrupt;

    /* the single bit mask representing the engine interrupt */
    u32 irq_bitmask;

    /* name of this engine */
    char *name;
    /* version of this engine */
    int version;
    /* descriptor prefetch capability */
    int max_extra_adj;
    /* user space scatter gather mapper */
    struct sg_mapping_t *sgm;
    /* total number of descriptors of completed transfers in this run */
    int desc_dequeued;
    /* engine service work */
    struct work_struct work;
    /* performance measurement transfer */
    struct xdma_performance_ioctl *xdma_perf;
    /* if the performance measurement transfer stopped, wake this queue,
     * we do not want to use the transfer waitqueue because the transfer
     * can disappear underneath us, while the engine structure remains. */
    wait_queue_head_t xdma_perf_wq;
};

/*
 * XDMA character device specific book keeping. Each bus has a character device,
 * the control bus has no XDMA engines attached to it.
 */
struct xdma_char {
    /* MAGIC_CHAR == 0xCCCCCCCC */
    unsigned long magic;
    /* parent device */
    struct xdma_dev *lro;
    /* character device major:minor */
    dev_t cdevno;
    /* character device (embedded struct) */
    struct cdev cdev;
    /* for character devices on a control bus, -1 otherwise */
    int bar;
    /* for character device interfaces to the data bus, the SG DMA read engine */
    struct xdma_engine *engine;
    /* sysfs device */
    struct device *sys_device;
};

/*
 * XDMA PCIe device specific bookkeeping
 */
struct xdma_dev {
    /* MAGIC_DEVICE == 0xDDDDDDDD */
    unsigned long magic;
    /* the kernel pci device data structure provided by probe() */
    struct pci_dev *pci_dev;

    /*
     * kernel virtual address of the mapped BAR regions. See (un)map_bars().
     */
    void *__iomem bar[XDMA_BAR_NUM];
    /*
     * bus address of the descriptor list in Root Complex memory
     */
    dma_addr_t table_bus;
    /* if the device regions could not be allocated, assume and remember it
     * is in use by another driver; this driver must not disable the device.
     */
    int regions_in_use;
    /* whether msi was enabled for the device */
    int msi_enabled;

    struct msix_entry entry[32];

    /* whether this driver could obtain the regions */
    int got_regions;
    /* irq line succesfully requested by this driver, -1 otherwise */
    int irq_line;

    /* board revision */
    u8 revision;
    /* core capabilities */
    u32 capabilities;
#define CAP_64BIT_DMA 2
#define CAP_64BIT_DESC 4
#define CAP_ENGINE_WRITE 8
#define CAP_ENGINE_READ 16
    /* interrupt count, incremented by the interrupt handler */
    int irq_count;
    /* instance number */
    int instance;
    /* major number */
    int major;
    /* character device major:minor base */
    dev_t cdevno_base;
    /* character device structures */
    struct xdma_char *sgdma_char_dev;
    /* number of engines in the system */
    int engines_num;
    struct xdma_engine *engine[XDMA_CHANNEL_NUM_MAX][2];

    /* cumulated (OR'd) irq events */
    u32 events_irq;
    /* spinlock to atomically change events_irq */
    spinlock_t events_lock;
    /* wait queue for synchronously waiting threads */
    wait_queue_head_t events_wq;
};

struct xdma_target_bridge {
    /* 0xBBBBBBBB */
    unsigned long magic;
};

struct xdma_transfer *engine_cyclic_stop (struct xdma_engine *engine);
void engine_alignments (struct xdma_engine *engine);
ssize_t char_sgdma_read_write (struct xdma_dev *lro, struct xdma_sgdma_ioctl *sgdma_opt, int dir_to_dev);
ssize_t char_sgdma_read_cyclic (struct xdma_dev *lro, struct xdma_sgdma_ioctl *sgdma_opt, int dir_to_dev);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
int char_sgdma_ioctl (struct inode *in, struct file *file, unsigned int cmd, unsigned long arg);
#else
long char_sgdma_ioctl (struct file *file, unsigned int cmd, unsigned long arg);
#endif

