#ifndef __XDMA_H
#define __XDMA_H

#include <sys/ioctl.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>

#include "xdma-ioctl.h"

// 2GB
#define DRAM_SIZE (2 * 1024 * 1024 * 1024U)

#endif // __XDMA_H

