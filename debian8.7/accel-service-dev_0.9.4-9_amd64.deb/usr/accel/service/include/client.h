#pragma once

#include "accel.h"

namespace accel {
namespace cv {



class client {

public:

    virtual ~client () {};
};



} // namespace cv
} // namespace accel

