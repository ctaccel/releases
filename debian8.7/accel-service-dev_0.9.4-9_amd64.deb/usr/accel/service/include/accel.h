#pragma once


namespace accel {



static const unsigned int auth_len = 9;

static const char auth_name[] = "accel_req";



namespace feature {

static const unsigned int count = 4;

enum name { fake_copy = 0,
            jpeg_jpeg,
            jpeg_open,
            webp_save
          };

static const unsigned int char_len = 9;

static const char * char_name[] = { "fake_copy",
                                    "jpeg_jpeg",
                                    "jpeg_open",
                                    "webp_save"
                                  };

} // namespace feature



namespace status {

enum name { failed = 0,
            empty,
            queued,
            sent,
            started1, // started webp kernel 1
            done1,    // done webp kernel 1
            sent1,    // sent webp kemans results
            started2, // started webp kernel 2
            done2,    // done webp kernel 2
            started,
            done
          };

static const unsigned int char_len = 8;

static const char * char_name[] = { "failed__",
                                    "empty___",
                                    "queued__",
                                    "sent____",
                                    "started1",
                                    "done1___",
                                    "sent1___",
                                    "started2",
                                    "done2___",
                                    "started_",
                                    "done____"
                                  };

} // namespace status



} // namespace accel

