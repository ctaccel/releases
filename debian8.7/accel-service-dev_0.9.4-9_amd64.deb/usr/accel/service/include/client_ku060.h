#pragma once

#include <iomanip>
#include <iostream>

#include <boost/asio.hpp>
#include <boost/smart_ptr.hpp>

#include "client.h"

namespace accel {
namespace cv {



class client_ku060 : public client {

public:

    client_ku060 (const std::string &endpoint_name);

    ~client_ku060();

    bool process (const accel::feature::name feature,
                  const unsigned int   in_reg_len,
                  const unsigned char *in_reg_buff,
                  const unsigned int   in_data_len,
                  const unsigned char *in_data_buff,
                  unsigned int    &out_reg_len,
                  unsigned char * &out_reg_buff,
                  unsigned int    &out_data_len,
                  unsigned char * &out_data_buff);

private:

    boost::asio::io_service io_service_;

    boost::asio::local::stream_protocol::socket socket_;

    boost::asio::local::stream_protocol::endpoint endpoint_;
};



} // namespace cv
} // namespace accel

