#include "xdma-core.h"
#include "xdma-ioctl.h"

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
int char_sgdma_ioctl (struct inode *in, struct file *file, unsigned int cmd, unsigned long arg)
#else
long char_sgdma_ioctl (struct file *file, unsigned int cmd, unsigned long arg)
#endif
{
    int rc = 0;
    struct xdma_char *lro_char;
    struct xdma_dev *lro;

    // check cmd type and value
    if (_IOC_TYPE (cmd) != XDMA_IOCTL_MAGIC) {
        return -ENOTTY;
    }

    if (_IOC_NR (cmd) > XDMA_IOCTL_MAX_CMD) {
        return -ENOTTY;
    }

    // fetch device specific data stored earlier during open
    lro_char = (struct xdma_char *)file->private_data;
    BUG_ON (!lro_char);
    BUG_ON (lro_char->magic != MAGIC_CHAR);

    lro = lro_char->lro;
    BUG_ON (!lro);
    BUG_ON (lro->magic != MAGIC_DEVICE);

    switch (cmd) {
        case IOCTL_XDMA_EVENTS_READ: {
            u32 events_user;
            unsigned long flags;

            // sleep until any interrupt events have occurred, or a signal arrived
            rc = wait_event_interruptible_timeout (lro->events_wq, lro->events_irq != 0, HZ);

            if (rc > 0) {
                // condition evaluated to true after the timeout elapsed,
                // the remaining jiffies (at least 1) if the condition evaluated to true before the timeout elapsed
            }
            else if (rc == -ERESTARTSYS) {
                // wait_event_interruptible_timeout() was interrupted by a signal
                return -ERESTARTSYS;
            }
            else {
                // printk (KERN_INFO "char_events_read(): wait_event_interruptible() = %d\n", rc);
                return -ERESTARTSYS;
            }

            // atomically decide which events are passed to the user
            spin_lock_irqsave (&lro->events_lock, flags);
            events_user = lro->events_irq;
            lro->events_irq = 0;
            spin_unlock_irqrestore (&lro->events_lock, flags);

            if (copy_to_user ((void __user *) arg, &events_user, 4)) {
                dbg_ioctl ("copy_to_user failed\n");
                rc = -EFAULT;
            }
        }
        break;

        case IOCTL_XDMA_CTRL_READ: {
            struct xdma_bar_register_ioctl register_opt;
            void *reg;
            u32 val;

            if (!copy_from_user (&register_opt, (struct xdma_bar_register_ioctl*) arg, sizeof (struct xdma_bar_register_ioctl))) {
                // first address is BAR base plus file position offset
                reg = lro->bar[register_opt.bar] + register_opt.card_offset;
                val = read_register (reg);
                if (copy_to_user (register_opt.buffer, &val, 4)) {
                    dbg_ioctl ("copy_to_user failed\n");
                    rc = -EFAULT;
                }
            }
            else {
                dbg_ioctl ("copy_from_user failed\n");
                rc = -EFAULT;
            }
        }
        break;

        case IOCTL_XDMA_CTRL_WRITE: {
            struct xdma_bar_register_ioctl register_opt;
            void *reg;
            u32 val;

            if (!copy_from_user (&register_opt, (struct xdma_bar_register_ioctl*) arg, sizeof (struct xdma_bar_register_ioctl))) {
                // first address is BAR base plus file position offset
                reg = lro->bar[register_opt.bar] + register_opt.card_offset;
                if (copy_from_user (&val, (void __user *) register_opt.buffer, 4)) {
                    dbg_ioctl ("copy_from_user failed\n");
                    rc = -EFAULT;
                    break;
                }
                write_register (val, reg);
            }
            else {
                dbg_ioctl ("copy_from_user failed\n");
                rc = -EFAULT;
            }
        }
        break;

        // read from the device
        // iterate over the userspace buffer,
        // taking at most 255 * PAGE_SIZE bytes for each DMA transfer.
        // for each transfer, get the user pages, build a sglist, map, descriptor table,
        // submit the transfer, wait for the interrupt handler to wake us on completion,
        // free the sglist and descriptors.
        case IOCTL_XDMA_SGDMA_READ: {
            struct xdma_sgdma_ioctl sgdma_opt;
            struct xdma_engine *engine;

            if (!copy_from_user (&sgdma_opt, (struct xdma_sgdma_ioctl*) arg, sizeof (struct xdma_sgdma_ioctl))) {
                engine = lro->engine[sgdma_opt.channel][sgdma_opt.engine];
                // detect non-supported directions
                BUG_ON (!engine);
                BUG_ON (engine->magic != MAGIC_ENGINE);

                if (1 && !engine->dir_to_dev && engine->rx_buffer && engine->rx_transfer_cyclic) {
                    return char_sgdma_read_cyclic (lro, &sgdma_opt, 0); // dir_to_dev = 0
                }
                else {
                    return char_sgdma_read_write (lro, &sgdma_opt, 0); // dir_to_dev = 0
                }
            }
            else {
                dbg_ioctl ("copy_from_user failed\n");
                rc = -EFAULT;
            }
        }
        break;

        // write to the device
        case IOCTL_XDMA_SGDMA_WRITE: {
            struct xdma_sgdma_ioctl sgdma_opt;

            if (!copy_from_user (&sgdma_opt, (struct xdma_sgdma_ioctl*) arg, sizeof (struct xdma_sgdma_ioctl))) {
                char_sgdma_read_write (lro, &sgdma_opt, 1); // dir_to_dev = 1
            }
            else {
                dbg_ioctl ("copy_from_user failed\n");
                rc = -EFAULT;
            }
        }
        break;

        default:
            rc = -EINVAL;
            break;
    }

    return rc;
}

