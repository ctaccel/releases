#ifndef __XDMA_IOCTL_H
#define __XDMA_IOCTL_H

#include <linux/version.h>
#include <linux/fs.h>

struct xdma_performance_ioctl {
    // IOCTL_XDMA_IOCTL_Vx
    uint32_t version;
    uint32_t transfer_size;
    // measurement
    uint32_t stopped;
    uint32_t iterations;
    uint64_t clock_cycle_count;
    uint64_t data_cycle_count;
    uint64_t pending_count;
};

// register operations
struct xdma_bar_register_ioctl {
    unsigned int bar;               // Base Addres Register (BAR) to access
    unsigned long long card_offset; // Byte starting offset in BAR
    unsigned long long length;      // Transaction length in bytes
    unsigned char *buffer;          // Buffer Pointer
};

// memory operations
struct xdma_sgdma_ioctl {
    unsigned int channel;           //Channel number
    unsigned int engine;            //Engine number
    unsigned long long addr_offset; // Byte-address in device
    unsigned long long length;      // Transaction length in bytes
    unsigned char *buffer;          // Buffer Pointer
};

// magic numbers
#define XDMA_IOCTL_MAGIC 'C' // Magic number for use in IOCTLs
#define XDMA_IOCTL_MAX_CMD 5 // Total number of IOCTLs

// IOCTL codes
#define IOCTL_XDMA_EVENTS_READ _IOR(XDMA_IOCTL_MAGIC, 1, int)
#define IOCTL_XDMA_CTRL_READ   _IOWR(XDMA_IOCTL_MAGIC, 2, struct xdma_bar_register_ioctl *)
#define IOCTL_XDMA_CTRL_WRITE  _IOWR(XDMA_IOCTL_MAGIC, 3, struct xdma_bar_register_ioctl *)
#define IOCTL_XDMA_SGDMA_READ  _IOWR(XDMA_IOCTL_MAGIC, 4, struct xdma_sgdma_ioctl *)
#define IOCTL_XDMA_SGDMA_WRITE _IOWR(XDMA_IOCTL_MAGIC, 5, struct xdma_sgdma_ioctl *)

#endif //__XDMA_IOCTL_H

